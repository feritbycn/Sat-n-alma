# Kendi oyununuzu Test Lab'a bağlama (yalnızca debug)

Test Lab, bakiyeyi oyununuza **oyunun kendi alıcı kodu** aracılığıyla iletir. Alıcı yoksa hiçbir şey olmaz. Bu bir simülasyondur; Google Play, token veya makbuz yoktur. Başka geliştiricilerin oyunlarında çalışmaz.

## 1) İmza (zorunlu)
İzin `signature` düzeyindedir: oyununuz **Test Lab ile aynı anahtarla** imzalanmalıdır. Test Lab depodaki `keystore/debug.keystore` ile imzalanır (şifre `android`, alias `androiddebugkey`). Oyununuzun **debug** derlemesini aynı keystore ile imzalayın (Gradle'da `signingConfigs.debug` ya da Unity'de Custom Keystore). Release derlemesine bu keystore'u KOYMAYIN.

## 2) Manifest (yalnızca `src/debug/AndroidManifest.xml` — release'e girmez)
```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="com.example.testlab.permission.SEND_TEST_EVENT" />
    <application>
        <receiver
            android:name="com.sizin.oyun.TestLabReceiver"
            android:exported="true"
            android:permission="com.example.testlab.permission.SEND_TEST_EVENT">
            <intent-filter>
                <action android:name="com.example.testlab.action.TEST_EVENT" />
            </intent-filter>
        </receiver>
    </application>
</manifest>
```
Test Lab'ın izni tanımladığı kurulu olmalıdır (önce Test Lab, sonra oyun kurulur).

## 3) Alıcı (`src/debug/java/.../TestLabReceiver.kt`)
```kotlin
class TestLabReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.getStringExtra("source") != "TestLab-simulation") return
        val balance = intent.getIntExtra("balance", -1)
        val packs = intent.getStringArrayListExtra("packs") ?: arrayListOf()
        if (balance < 0) return
        // KENDİ oyununuzun kaydet/yükle koduna bağlayın:
        MyGameSave.setGold(context, balance)
        MyGameSave.setOwnedPacks(context, packs.toSet())   // örn. "starter_pack", "special_test_pack"
        resultCode = Activity.RESULT_OK   // Test Lab'a "aldım" onayı
    }
}
```
Oyun açıksa arayüzü yenilemek için kendi içinizde bir olay/flow tetikleyin. Ürün kimlikleri: `starter_pack`, `special_test_pack`.

## 4) Kullanım
Oyunu açın → Test Lab → **Altın ve paketler** → "Kendi oyuma gönder" → oyunun paket adını yazın → gönderin. "Oyun onayladı" görürseniz alıcı çalışmıştır.

Unity kullanıyorsanız alıcıyı Android eklentisi (Java/Kotlin, yalnızca debug) olarak yazıp kaydetme verisini `PlayerPrefs`/dosya üzerinden Unity tarafına okutmanız gerekir.
