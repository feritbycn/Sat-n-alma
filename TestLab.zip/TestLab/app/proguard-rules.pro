# Ek kural gerekmez (yansıma/serileştirme kütüphanesi kullanılmıyor).
