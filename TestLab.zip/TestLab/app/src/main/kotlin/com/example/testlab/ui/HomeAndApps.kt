package com.example.testlab.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.testlab.domain.TestStatus

enum class Screen(val title: String, val description: String, val onHome: Boolean) {
    HOME("Test Lab", "", false),
    APPS("Uygulamalar", "Yüklü uygulamaları listele, seç, aç", true),
    BULK("Toplu test paneli", "Seçilen uygulamalar için test notu ve durum", false),
    PURCHASE("Test satın alma", "Simüle edilmiş satın alma senaryoları", true),
    WALLET("Altın ve paketler", "Bakiye, harcama, sahip olunan paketler", true),
    ADS("Reklam testi", "Test reklamı yükleme/hata/gösterim simülasyonu", true),
    INTEGRITY("İmza ve bütünlük testi", "Kendi uygulamanın imza parmak izi", true),
    HISTORY("İşlem geçmişi", "Satın alma, altın ve uygulama test kayıtları", true),
    SETTINGS("Ayarlar", "Başlangıç bakiyesi, ürün miktarları, tema", true),
}

@Composable
fun HomeScreen(vm: HomeViewModel, onNavigate: (Screen) -> Unit) {
    val wallet by vm.wallet.collectAsStateWithLifecycle()
    val records by vm.records.collectAsStateWithLifecycle()
    ScreenScaffold("Test Lab", null) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                SimBanner(
                    "Bu uygulama KENDİ geliştirdiğiniz uygulamaları test etmek içindir. Satın alma, altın ve reklam " +
                        "sonuçları SİMÜLASYONDUR; gerçek ödeme veya Google Play kaydı değildir.",
                )
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Test bakiyesi (simülasyon)", style = MaterialTheme.typography.labelMedium)
                        Text("${wallet.balance} altın", style = MaterialTheme.typography.headlineMedium)
                        Text("Seçilen uygulama: ${records.selected.size}", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            items(Screen.entries.filter { it.onHome }, key = { it.name }) { s ->
                Card(Modifier.fillMaxWidth().clickable { onNavigate(s) }) {
                    Column(Modifier.padding(16.dp)) {
                        Text(s.title, style = MaterialTheme.typography.titleMedium)
                        Text(s.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun AppsScreen(vm: AppsViewModel, onBack: () -> Unit, onOpenBulk: () -> Unit) {
    val apps by vm.visible.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val records by vm.records.collectAsStateWithLifecycle()
    val notice by vm.notice.collectAsStateWithLifecycle()

    ScreenScaffold("Uygulamalar", onBack) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                OutlinedTextField(
                    value = query, onValueChange = vm::setQuery, singleLine = true,
                    label = { Text("Ad veya paket adı ara") }, modifier = Modifier.fillMaxWidth(),
                )
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = vm::selectAllVisible, modifier = Modifier.weight(1f)) { Text("Tümünü Seç") }
                    OutlinedButton(onClick = vm::clearSelection, modifier = Modifier.weight(1f)) { Text("Seçimi Temizle") }
                }
            }
            item {
                Button(onClick = onOpenBulk, enabled = records.selected.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
                    Text("Seçilenleri Test Et (${records.selected.size})")
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Seçilen uygulamalar (${records.selected.size})", style = MaterialTheme.typography.titleSmall)
                        Text(
                            if (records.selected.isEmpty()) "Henüz seçim yok."
                            else records.selected.joinToString("\n") { "• ${records.labels[it] ?: it}  ($it)" },
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
            notice?.let { n -> item { MessageCard(false, n) } }
            if (loading) item { CircularProgressIndicator() }
            else if (apps.isEmpty()) item { Text("Eşleşen uygulama yok.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(apps, key = { it.packageName }) { app ->
                val checked = app.packageName in records.selected
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Checkbox(checked = checked, onCheckedChange = { vm.toggle(app) })
                        AppIcon(app.packageName)
                        Column(Modifier.weight(1f)) {
                            Text(app.label, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                            Text(app.packageName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                            Text("Yüklü" + if (app.isSystem) " · sistem" else "", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                        OutlinedButton(onClick = { vm.open(app.packageName) }) { Text("Aç") }
                    }
                }
            }
            item {
                Text(
                    "Not: Android paket görünürlüğü kuralları gereği yalnızca başlatılabilir (ana ekranda simgesi olan) uygulamalar listelenir. " +
                        "Başka uygulamaların verilerine erişilmez, hiçbir uygulama değiştirilmez.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
fun BulkScreen(vm: AppsViewModel, onBack: () -> Unit, onHistory: () -> Unit) {
    val records by vm.records.collectAsStateWithLifecycle()
    val notice by vm.notice.collectAsStateWithLifecycle()

    ScreenScaffold("Toplu test paneli", onBack) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Text("Seçilen uygulama sayısı: ${records.selected.size}", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Durum ve notlar yalnızca bu uygulamada saklanır. Seçilen uygulamalara dışarıdan müdahale edilmez.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            notice?.let { n -> item { MessageCard(false, n) } }
            items(records.selected, key = { it }) { pkg ->
                val rec = records.records[pkg]
                var status by remember(pkg, rec) { mutableStateOf(rec?.status ?: TestStatus.PENDING) }
                var note by remember(pkg, rec) { mutableStateOf(rec?.note ?: "") }
                val installed = remember(pkg) { vm.isInstalled(pkg) }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            AppIcon(pkg, 40.dp)
                            Column(Modifier.weight(1f)) {
                                Text(records.labels[pkg] ?: pkg, style = MaterialTheme.typography.titleSmall)
                                Text(pkg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    if (installed) "Yüklü" else "Yüklü değil / görünmüyor",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (installed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                )
                            }
                            OutlinedButton(onClick = { vm.open(pkg) }, enabled = installed) { Text("Aç") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TestStatus.entries.forEach { st ->
                                FilterChip(selected = status == st, onClick = { status = st }, label = { Text(st.label) })
                            }
                        }
                        OutlinedTextField(
                            value = note, onValueChange = { note = it }, label = { Text("Test notu") },
                            modifier = Modifier.fillMaxWidth(), minLines = 2,
                        )
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.saveRecord(pkg, status, note) }) { Text("Kaydet") }
                            Text(
                                rec?.let { "Kayıtlı: ${it.status.label} · ${fmtTime(it.updatedAt)}" } ?: "Henüz kaydedilmedi",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = vm::clearSelection, modifier = Modifier.weight(1f)) { Text("Seçimi temizle") }
                    OutlinedButton(onClick = onHistory, modifier = Modifier.weight(1f)) { Text("Test geçmişi") }
                }
            }
        }
    }
}

