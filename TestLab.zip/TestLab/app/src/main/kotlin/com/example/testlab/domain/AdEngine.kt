package com.example.testlab.domain

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Reklam davranışı SİMÜLATÖRÜ. Gerçek bir reklam SDK'sı içermez ve başka uygulamaların
 * reklamlarına dokunmaz. Kendi uygulamanızda yükleme/hata/gösterim akışını denemek içindir.
 */
enum class AdLoadScenario(val label: String) {
    SUCCESS("Yükleme başarılı"),
    ERROR("Yükleme hatası"),
    NO_FILL("Reklam yok (no fill)"),
    TIMEOUT("Zaman aşımı"),
}

sealed interface AdState {
    data object Idle : AdState
    data object Loading : AdState
    data object Loaded : AdState
    data object Showing : AdState
    data class Failed(val reason: String) : AdState
    data class Disabled(val reason: String) : AdState
}

data class AdLog(val time: Long, val text: String)

class AdEngine(
    private val loadDelayMs: Long = 1_200,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private val _state = MutableStateFlow<AdState>(AdState.Idle)
    val state: StateFlow<AdState> = _state.asStateFlow()

    private val _log = MutableStateFlow<List<AdLog>>(emptyList())
    val log: StateFlow<List<AdLog>> = _log.asStateFlow()

    private val _impressions = MutableStateFlow(0)
    val impressions: StateFlow<Int> = _impressions.asStateFlow()

    private fun note(text: String) = _log.update { (listOf(AdLog(clock(), text)) + it).take(50) }

    /** [disabledReason] doluysa reklamlar kapalıdır (test reklamları kapalı veya reklamsız test sürümü). */
    suspend fun load(scenario: AdLoadScenario, disabledReason: String?) {
        if (disabledReason != null) {
            _state.value = AdState.Disabled(disabledReason)
            note("Yükleme engellendi: $disabledReason")
            return
        }
        if (_state.value is AdState.Loading || _state.value is AdState.Showing) {
            note("Yükleme yok sayıldı: işlem sürüyor")
            return
        }
        _state.value = AdState.Loading
        note("Test reklamı yükleniyor (${scenario.label})")
        delay(loadDelayMs)
        when (scenario) {
            AdLoadScenario.SUCCESS -> { _state.value = AdState.Loaded; note("Yüklendi (simülasyon)") }
            AdLoadScenario.ERROR -> fail("Yükleme hatası: dahili hata (simüle)")
            AdLoadScenario.NO_FILL -> fail("Gösterilecek reklam bulunamadı (simüle)")
            AdLoadScenario.TIMEOUT -> fail("Zaman aşımı (simüle)")
        }
    }

    private fun fail(reason: String) { _state.value = AdState.Failed(reason); note(reason) }

    /** Yalnızca yüklenmiş reklam gösterilebilir. */
    fun show(): Boolean {
        if (_state.value != AdState.Loaded) { note("Gösterim reddedildi: reklam yüklü değil"); return false }
        _state.value = AdState.Showing
        note("Test reklamı gösteriliyor")
        return true
    }

    fun close() {
        if (_state.value != AdState.Showing) return
        _impressions.update { it + 1 }
        _state.value = AdState.Idle
        note("Reklam kapatıldı; gösterim sayısı arttı")
    }

    fun reset() {
        _state.value = AdState.Idle
        _impressions.value = 0
        _log.value = emptyList()
    }
}
