package com.example.testlab.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.testlab.BuildConfig
import com.example.testlab.domain.AdLoadScenario
import com.example.testlab.domain.AdState
import com.example.testlab.domain.IntegrityOverride
import com.example.testlab.domain.Verdict

@Composable
fun AdsScreen(vm: AdViewModel, onBack: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val log by vm.log.collectAsStateWithLifecycle()
    val impressions by vm.impressions.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var scenario by remember { mutableStateOf(AdLoadScenario.SUCCESS) }

    ScreenScaffold("Reklam testi", onBack) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                SimBanner(
                    "SİMÜLASYON: Bu ekran gerçek bir reklam SDK'sı içermez ve başka uygulamaların reklamlarına dokunmaz. " +
                        "Kendi uygulamanızda yükleme/hata/gösterim akışını denemek içindir.",
                )
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Test reklamları açık", Modifier.weight(1f))
                            Switch(checked = settings.adsEnabled, onCheckedChange = vm::setAdsEnabled)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Reklamsız test sürümü")
                                Text("Açıkken reklam yüklenmez (kendi uygulamanızı reklamsız denemek için).", style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = settings.adsRemoved, onCheckedChange = vm::setAdsRemoved)
                        }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Reklam durumu", style = MaterialTheme.typography.labelMedium)
                        Text(describe(state), style = MaterialTheme.typography.titleMedium)
                        Text("Gösterim sayısı (simülasyon): $impressions", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item { Text("Yükleme senaryosu", style = MaterialTheme.typography.titleSmall) }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(AdLoadScenario.entries) { s ->
                        FilterChip(selected = scenario == s, onClick = { scenario = s }, label = { Text(s.label) })
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.load(scenario) }, modifier = Modifier.weight(1f)) { Text("Test reklamı yükle") }
                    OutlinedButton(onClick = { vm.show() }, enabled = state == AdState.Loaded, modifier = Modifier.weight(1f)) { Text("Göster") }
                }
                OutlinedButton(onClick = vm::resetAds, modifier = Modifier.fillMaxWidth()) { Text("Sayaç ve günlüğü sıfırla") }
            }
            item { Text("Günlük", style = MaterialTheme.typography.titleSmall) }
            if (log.isEmpty()) item { Text("Henüz kayıt yok.") }
            items(log) { Text("${fmtTime(it.time)}  ${it.text}", style = MaterialTheme.typography.bodySmall) }
        }
    }

    if (state == AdState.Showing) {
        AlertDialog(
            onDismissRequest = vm::close,
            title = { Text("TEST REKLAMI (simülasyon)") },
            text = { Text("Bu gerçek bir reklam değildir. Kapatınca gösterim sayacı artar.") },
            confirmButton = { Button(onClick = vm::close) { Text("Kapat") } },
        )
    }
}

private fun describe(s: AdState): String = when (s) {
    AdState.Idle -> "Boşta"
    AdState.Loading -> "Yükleniyor…"
    AdState.Loaded -> "Yüklendi — gösterilebilir"
    AdState.Showing -> "Gösteriliyor"
    is AdState.Failed -> "Hata: ${s.reason}"
    is AdState.Disabled -> "Kapalı: ${s.reason}"
}

@Composable
fun IntegrityScreen(vm: IntegrityViewModel, onBack: () -> Unit) {
    val result by vm.result.collectAsStateWithLifecycle()
    val override by vm.override.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val info = vm.info
    val expected = vm.expected(settings)

    ScreenScaffold("İmza ve bütünlük testi", onBack) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                SimBanner(
                    "Bu ekran YALNIZCA bu uygulamanın kendi imzasını inceler. Başka uygulamaların imza doğrulamasına " +
                        "müdahale edilmez; imza kontrolü atlatılmaz, APK yeniden imzalanmaz.",
                )
            }
            if (info == null) {
                item { MessageCard(false, "İmza bilgisi okunamadı.") }
            } else {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        SelectionContainer {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Paket adı: ${info.packageName}")
                                Text("Sürüm: ${info.versionName ?: "—"} (kod ${info.versionCode})")
                                Text("Derleme türü: ${if (info.debugBuild) "DEBUG" else "RELEASE"}")
                                Text("Debuggable bayrağı: ${if (info.debuggableApp) "evet" else "hayır"}")
                                Text("Kurulum kaynağı: ${info.installer ?: "bilinmiyor"}")
                                Text("Birden çok imzacı: ${if (info.multipleSigners) "evet" else "hayır"}")
                                Text("İmza sertifikası SHA-256 (uzun basıp kopyalayabilirsiniz):", style = MaterialTheme.typography.labelMedium)
                                if (info.certSha256.isEmpty()) Text("—")
                                info.certSha256.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                                Text("Beklenen parmak izi: ${expected.ifBlank { "tanımlı değil (Ayarlar'dan girin)" }}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            item {
                val r = result
                val ok = r.verdict == Verdict.MATCH
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = when (r.verdict) {
                            Verdict.MATCH -> MaterialTheme.colorScheme.primaryContainer
                            Verdict.MISMATCH -> MaterialTheme.colorScheme.errorContainer
                            Verdict.NOT_CONFIGURED -> MaterialTheme.colorScheme.tertiaryContainer
                        },
                    ),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Doğrulama sonucu", style = MaterialTheme.typography.labelMedium)
                        Text(
                            r.verdict.label + if (r.simulated) "  [SİMÜLE — gerçek ölçüm değil]" else "  [gerçek ölçüm]",
                            style = MaterialTheme.typography.titleMedium,
                        )
                        if (ok && !r.simulated) Text("İmza, beklenen parmak iziyle eşleşiyor.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            if (BuildConfig.DEBUG) {
                item {
                    Text("Debug test denetimi (yalnızca DEBUG derlemesinde)", style = MaterialTheme.typography.titleSmall)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(IntegrityOverride.entries) { o ->
                            FilterChip(selected = override == o, onClick = { vm.setOverride(o) }, label = { Text(o.label) })
                        }
                    }
                }
            } else {
                item {
                    Text(
                        "Release derlemesi: gerçek imza ve bütünlük kontrolü korunur; sonuç zorlanamaz.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Debug ve release imzası farkı", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "• Debug: Android Studio / bu depodaki ortak debug anahtarıyla imzalanır; herkese bilinen bir anahtardır, " +
                                "yalnızca test içindir ve Google Play'e yüklenemez.\n" +
                                "• Release: yalnızca sizin sakladığınız özel anahtarla imzalanır. Parmak izi her anahtar için farklıdır; " +
                                "uygulama güncellemeleri aynı anahtarla imzalanmalıdır.\n" +
                                "• Play App Signing kullanırsanız kullanıcıya ulaşan APK'nın imzası Play'in uygulama imzalama anahtarıdır " +
                                "(yükleme anahtarınızdan farklı olabilir).\n" +
                                "• Bu ekranda ölçülen değer, cihaza kurulu APK'nın gerçek imzasıdır.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }
    }
}
