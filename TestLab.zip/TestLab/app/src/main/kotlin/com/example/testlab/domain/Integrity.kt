package com.example.testlab.domain

import java.security.MessageDigest

/**
 * KENDİ uygulamanızın imza kontrolü. Başka uygulamaların imzasını/doğrulamasını incelemez,
 * atlatmaz veya değiştirmez. Test sonucu "zorlama" yalnızca DEBUG derlemesinde etkindir;
 * release'te her zaman gerçek ölçüm kullanılır.
 */
enum class IntegrityOverride(val label: String) {
    REAL("Gerçek ölçüm"),
    FORCE_MATCH("Eşleşme (simüle)"),
    FORCE_MISMATCH("Uyuşmazlık (simüle)"),
    FORCE_NOT_CONFIGURED("Yapılandırılmamış (simüle)"),
}

enum class Verdict(val label: String) {
    MATCH("Eşleşiyor"),
    MISMATCH("UYUŞMUYOR"),
    NOT_CONFIGURED("Beklenen parmak izi tanımlı değil"),
}

data class IntegrityResult(val verdict: Verdict, val simulated: Boolean)

fun sha256Hex(bytes: ByteArray): String =
    MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02X".format(it) }

/** "AABB…" → "AA:BB:…" */
fun colonFormat(hex: String): String = hex.chunked(2).joinToString(":")

/** Boşluk, iki nokta ve büyük/küçük harf farklarını yok sayar. */
fun normalizeFingerprint(s: String): String = s.filter { it.isLetterOrDigit() }.uppercase()

fun evaluateIntegrity(
    actualCertSha256: List<String>,
    expected: String,
    override: IntegrityOverride,
    isDebugBuild: Boolean,
): IntegrityResult {
    // Release'te zorlama YOK SAYILIR.
    val effective = if (isDebugBuild) override else IntegrityOverride.REAL
    return when (effective) {
        IntegrityOverride.FORCE_MATCH -> IntegrityResult(Verdict.MATCH, true)
        IntegrityOverride.FORCE_MISMATCH -> IntegrityResult(Verdict.MISMATCH, true)
        IntegrityOverride.FORCE_NOT_CONFIGURED -> IntegrityResult(Verdict.NOT_CONFIGURED, true)
        IntegrityOverride.REAL -> {
            val exp = normalizeFingerprint(expected)
            val verdict = when {
                exp.isEmpty() -> Verdict.NOT_CONFIGURED
                actualCertSha256.any { normalizeFingerprint(it) == exp } -> Verdict.MATCH
                else -> Verdict.MISMATCH
            }
            IntegrityResult(verdict, false)
        }
    }
}
