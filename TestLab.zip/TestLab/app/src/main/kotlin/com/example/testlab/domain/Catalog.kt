package com.example.testlab.domain

enum class ProductKind { GOLD, PACK }

/**
 * Test ürünü. GOLD tüketilebilir (her satın almada altın eklenir), PACK kalıcıdır (bir kez sahip olunur).
 * defaultCoins, Ayarlar ekranından değiştirilebilir (bkz. Settings.coinOverrides).
 */
data class Product(
    val id: String,
    val title: String,
    val description: String,
    val kind: ProductKind,
    val defaultCoins: Int,
    val testPrice: String,
)

/** Altınla harcanabilen demo öğesi. */
data class ShopItem(val id: String, val title: String, val cost: Int)

object Catalog {
    val products = listOf(
        Product("gold_100", "100 Altın", "Tüketilebilir test ürünü", ProductKind.GOLD, 100, "Test: ₺0,00"),
        Product("gold_1000", "1.000 Altın", "Tüketilebilir test ürünü", ProductKind.GOLD, 1_000, "Test: ₺0,00"),
        Product("gold_5000", "5.000 Altın", "Tüketilebilir test ürünü", ProductKind.GOLD, 5_000, "Test: ₺0,00"),
        Product("starter_pack", "Başlangıç Paketi", "Kalıcı paket + altın", ProductKind.PACK, 500, "Test: ₺0,00"),
        Product("special_test_pack", "Özel Test Paketi", "Kalıcı paket (altın yok)", ProductKind.PACK, 0, "Test: ₺0,00"),
    )

    val shopItems = listOf(
        ShopItem("sword", "Kılıç", 250),
        ShopItem("shield", "Kalkan", 120),
        ShopItem("potion", "İksir", 50),
    )

    fun product(id: String?): Product? = products.firstOrNull { it.id == id }
    fun shopItem(id: String?): ShopItem? = shopItems.firstOrNull { it.id == id }
    fun title(productId: String?): String = product(productId)?.title ?: productId ?: "—"
}

enum class PurchaseScenario(val label: String) {
    SUCCESS("Başarılı"),
    USER_CANCELED("Kullanıcı iptali"),
    PAYMENT_ERROR("Ödeme hatası"),
    ALREADY_OWNED("Zaten sahip"),
    PENDING("Bekleyen"),
    RESTORE("Geri yükle / tekrar doğrula"),
}
