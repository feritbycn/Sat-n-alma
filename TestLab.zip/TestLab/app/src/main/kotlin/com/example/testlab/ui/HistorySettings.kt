package com.example.testlab.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.testlab.data.ThemeMode
import com.example.testlab.domain.Catalog

@Composable
fun HistoryScreen(vm: HistoryViewModel, onBack: () -> Unit) {
    val wallet by vm.wallet.collectAsStateWithLifecycle()
    val records by vm.records.collectAsStateWithLifecycle()
    var tab by remember { mutableStateOf(0) }

    ScreenScaffold("İşlem geçmişi", onBack) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("Altın / satın alma (${wallet.history.size})") })
                    FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("Uygulama testleri (${records.events.size})") })
                }
                Text("Tüm kayıtlar SİMÜLASYONDUR ve yalnızca bu cihazda saklanır.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (tab == 0) {
                if (wallet.history.isEmpty()) item { Text("Henüz işlem yok.") }
                items(wallet.history, key = { it.id }) { h ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${h.type.label} · ${fmtTime(h.time)}", style = MaterialTheme.typography.titleSmall)
                            Text("Ürün: ${Catalog.title(h.productId)}" + (h.productId?.let { " ($it)" } ?: ""), style = MaterialTheme.typography.bodySmall)
                            Text("Sonuç: ${h.result}", style = MaterialTheme.typography.bodySmall)
                            Text(
                                "Miktar: ${if (h.delta > 0) "+" else ""}${h.delta} altın · bakiye: ${h.balanceAfter}",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
            } else {
                if (records.events.isEmpty()) item { Text("Henüz uygulama test kaydı yok.") }
                items(records.events) { e ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${e.label} · ${e.status.label}", style = MaterialTheme.typography.titleSmall)
                            Text("${e.packageName} · ${fmtTime(e.time)}", style = MaterialTheme.typography.bodySmall)
                            if (e.note.isNotBlank()) Text("Not: ${e.note}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: SettingsViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()

    ScreenScaffold("Ayarlar", onBack) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { Text("Tema", style = MaterialTheme.typography.titleSmall) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { m ->
                        FilterChip(selected = s.themeMode == m, onClick = { vm.update { it.copy(themeMode = m) } }, label = { Text(m.label) })
                    }
                }
            }
            item {
                Text("Başlangıç bakiyesi", style = MaterialTheme.typography.titleSmall)
                Text("'Test bakiyesini sıfırla' bu değere döner.", style = MaterialTheme.typography.bodySmall)
                NumberField(
                    label = "Başlangıç bakiyesi (altın)",
                    value = s.initialBalance,
                    onValue = { v -> vm.update { it.copy(initialBalance = v) } },
                )
            }
            item { Text("Ürün başına altın miktarı", style = MaterialTheme.typography.titleSmall) }
            items(Catalog.products.filter { it.defaultCoins > 0 || it.kind.name == "GOLD" }, key = { it.id }) { p ->
                NumberField(
                    label = "${p.title} (${p.id})",
                    value = s.coinOverrides[p.id] ?: p.defaultCoins,
                    onValue = { v -> vm.update { it.copy(coinOverrides = it.coinOverrides + (p.id to v)) } },
                )
            }
            item {
                Text("Beklenen imza parmak izi", style = MaterialTheme.typography.titleSmall)
                Text(
                    "Release anahtarınızın SHA-256 değeri. Boş bırakılırsa derleme varsayılanı kullanılır.",
                    style = MaterialTheme.typography.bodySmall,
                )
                OutlinedTextField(
                    value = s.expectedCertOverride,
                    onValueChange = { v -> vm.update { it.copy(expectedCertOverride = v.trim()) } },
                    label = { Text("SHA-256 (AA:BB:… veya düz hex)") },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            item {
                Text(
                    "Reklam açma/kapama anahtarları 'Reklam testi' ekranındadır.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/** Boş/geçersiz girişte son geçerli değeri korur; yalnızca 0..10.000.000 kabul eder. */
@Composable
private fun NumberField(label: String, value: Int, onValue: (Int) -> Unit) {
    var text by remember(value) { mutableStateOf(value.toString()) }
    OutlinedTextField(
        value = text,
        onValueChange = { t ->
            val digits = t.filter { it.isDigit() }.take(8)
            text = digits
            digits.toIntOrNull()?.takeIf { it in 0..10_000_000 }?.let(onValue)
        },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth(),
    )
}
