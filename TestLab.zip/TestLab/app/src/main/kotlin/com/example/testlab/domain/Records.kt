package com.example.testlab.domain

import org.json.JSONArray
import org.json.JSONObject

/**
 * Seçilen uygulamalar için YALNIZCA bu uygulamada tutulan test notları ve durumları.
 * Başka uygulamalara hiçbir müdahale yapılmaz; yalnızca açılabilir ve kayıt altına alınır.
 */
enum class TestStatus(val label: String) {
    PENDING("Beklemede"),
    SUCCESS("Başarılı"),
    FAILED("Başarısız"),
}

data class AppTestRecord(val packageName: String, val label: String, val status: TestStatus, val note: String, val updatedAt: Long)

data class RecordEvent(val time: Long, val packageName: String, val label: String, val status: TestStatus, val note: String)

data class RecordsState(
    /** Seçim sırası korunur. */
    val selected: List<String> = emptyList(),
    val labels: Map<String, String> = emptyMap(),
    val records: Map<String, AppTestRecord> = emptyMap(),
    /** En yeni başta. */
    val events: List<RecordEvent> = emptyList(),
)

object RecordsLogic {
    private const val MAX_EVENTS = 300

    fun toggle(s: RecordsState, pkg: String, label: String): RecordsState =
        if (pkg in s.selected) s.copy(selected = s.selected - pkg)
        else s.copy(selected = s.selected + pkg, labels = s.labels + (pkg to label))

    fun selectAll(s: RecordsState, apps: List<Pair<String, String>>): RecordsState {
        val newOnes = apps.filter { it.first !in s.selected }
        return s.copy(
            selected = s.selected + newOnes.map { it.first },
            labels = s.labels + newOnes.toMap(),
        )
    }

    fun clear(s: RecordsState) = s.copy(selected = emptyList())

    fun save(s: RecordsState, pkg: String, status: TestStatus, note: String, now: Long): RecordsState {
        val label = s.labels[pkg] ?: pkg
        val rec = AppTestRecord(pkg, label, status, note.trim(), now)
        return s.copy(
            records = s.records + (pkg to rec),
            events = (listOf(RecordEvent(now, pkg, label, status, rec.note)) + s.events).take(MAX_EVENTS),
        )
    }
}

fun RecordsState.toJson(): JSONObject = JSONObject()
    .put("selected", JSONArray(selected))
    .put("labels", JSONObject().also { o -> labels.forEach { (k, v) -> o.put(k, v) } })
    .put("records", JSONArray(records.values.map {
        JSONObject().put("pkg", it.packageName).put("label", it.label).put("status", it.status.name)
            .put("note", it.note).put("at", it.updatedAt)
    }))
    .put("events", JSONArray(events.map {
        JSONObject().put("time", it.time).put("pkg", it.packageName).put("label", it.label)
            .put("status", it.status.name).put("note", it.note)
    }))

fun recordsFromJson(o: JSONObject): RecordsState {
    fun status(n: String) = TestStatus.entries.firstOrNull { it.name == n } ?: TestStatus.PENDING
    val sel = o.optJSONArray("selected")
    val lab = o.optJSONObject("labels")
    val recs = o.optJSONArray("records")
    val evs = o.optJSONArray("events")
    return RecordsState(
        selected = (0 until (sel?.length() ?: 0)).map { sel!!.getString(it) },
        labels = lab?.let { o -> o.keys().asSequence().associateWith { k -> o.getString(k) } } ?: emptyMap(),
        records = (0 until (recs?.length() ?: 0)).map {
            val r = recs!!.getJSONObject(it)
            AppTestRecord(r.getString("pkg"), r.optString("label"), status(r.optString("status")), r.optString("note"), r.optLong("at"))
        }.associateBy { it.packageName },
        events = (0 until (evs?.length() ?: 0)).map {
            val e = evs!!.getJSONObject(it)
            RecordEvent(e.optLong("time"), e.getString("pkg"), e.optString("label"), status(e.optString("status")), e.optString("note"))
        },
    )
}
