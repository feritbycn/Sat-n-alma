package com.example.testlab.data

import android.content.Context
import com.example.testlab.BuildConfig
import com.example.testlab.domain.RecordsLogic
import com.example.testlab.domain.RecordsState
import com.example.testlab.domain.TestStatus
import com.example.testlab.domain.WalletAction
import com.example.testlab.domain.WalletEngine
import com.example.testlab.domain.WalletResult
import com.example.testlab.domain.WalletState
import com.example.testlab.domain.recordsFromJson
import com.example.testlab.domain.toJson
import com.example.testlab.domain.walletFromJson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

/** Küçük anahtar-değer deposu (SharedPreferences). Bakiye ve kayıtlar uygulama kapanınca da korunur. */
class JsonPrefs(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("testlab_store", Context.MODE_PRIVATE)
    fun read(key: String): JSONObject? = prefs.getString(key, null)?.let { runCatching { JSONObject(it) }.getOrNull() }
    fun write(key: String, value: JSONObject) = prefs.edit().putString(key, value.toString()).apply()
}

// ---------- Ayarlar ----------

enum class ThemeMode(val label: String) { DARK("Koyu"), LIGHT("Açık"), SYSTEM("Sistem") }

data class Settings(
    val initialBalance: Int = 0,
    /** Ürün kimliği → altın miktarı (varsayılanı geçersiz kılar). */
    val coinOverrides: Map<String, Int> = emptyMap(),
    val adsEnabled: Boolean = true,
    /** Reklamsız test sürümü: açıksa reklam testi yüklenmez. */
    val adsRemoved: Boolean = BuildConfig.ADS_DISABLED_BY_DEFAULT,
    val themeMode: ThemeMode = ThemeMode.DARK,
    /** Kendi release anahtarınızın SHA-256 parmak izi; boşsa derleme varsayılanı kullanılır. */
    val expectedCertOverride: String = "",
)

class SettingsRepository(private val store: JsonPrefs) {
    private val _state = MutableStateFlow(load())
    val state: StateFlow<Settings> = _state.asStateFlow()

    fun update(transform: (Settings) -> Settings) {
        _state.value = transform(_state.value).also { save(it) }
    }

    private fun load(): Settings {
        val o = store.read("settings") ?: return Settings()
        val ov = o.optJSONObject("coins")
        return Settings(
            initialBalance = o.optInt("initialBalance", 0),
            coinOverrides = ov?.let { j -> j.keys().asSequence().associateWith { k -> j.getInt(k) } } ?: emptyMap(),
            adsEnabled = o.optBoolean("adsEnabled", true),
            adsRemoved = o.optBoolean("adsRemoved", BuildConfig.ADS_DISABLED_BY_DEFAULT),
            themeMode = ThemeMode.entries.firstOrNull { it.name == o.optString("theme") } ?: ThemeMode.DARK,
            expectedCertOverride = o.optString("expectedCert", ""),
        )
    }

    private fun save(s: Settings) = store.write(
        "settings",
        JSONObject()
            .put("initialBalance", s.initialBalance)
            .put("coins", JSONObject().also { o -> s.coinOverrides.forEach { (k, v) -> o.put(k, v) } })
            .put("adsEnabled", s.adsEnabled)
            .put("adsRemoved", s.adsRemoved)
            .put("theme", s.themeMode.name)
            .put("expectedCert", s.expectedCertOverride),
    )
}

// ---------- Cüzdan ----------

class WalletRepository(private val store: JsonPrefs, private val clock: () -> Long = System::currentTimeMillis) {
    private val _state = MutableStateFlow(store.read("wallet")?.let { runCatching { walletFromJson(it) }.getOrNull() } ?: WalletState())
    val state: StateFlow<WalletState> = _state.asStateFlow()

    @Synchronized
    fun apply(action: WalletAction): WalletResult {
        val r = WalletEngine.reduce(_state.value, action, clock())
        if (r.state != _state.value) {
            _state.value = r.state
            store.write("wallet", r.state.toJson())
        }
        return r
    }
}

// ---------- Uygulama test kayıtları ----------

class RecordsRepository(private val store: JsonPrefs, private val clock: () -> Long = System::currentTimeMillis) {
    private val _state = MutableStateFlow(store.read("records")?.let { runCatching { recordsFromJson(it) }.getOrNull() } ?: RecordsState())
    val state: StateFlow<RecordsState> = _state.asStateFlow()

    private fun commit(next: RecordsState) {
        _state.value = next
        store.write("records", next.toJson())
    }

    @Synchronized fun toggle(pkg: String, label: String) = commit(RecordsLogic.toggle(_state.value, pkg, label))
    @Synchronized fun selectAll(apps: List<Pair<String, String>>) = commit(RecordsLogic.selectAll(_state.value, apps))
    @Synchronized fun clearSelection() = commit(RecordsLogic.clear(_state.value))
    @Synchronized fun save(pkg: String, status: TestStatus, note: String) =
        commit(RecordsLogic.save(_state.value, pkg, status, note, clock()))
}
