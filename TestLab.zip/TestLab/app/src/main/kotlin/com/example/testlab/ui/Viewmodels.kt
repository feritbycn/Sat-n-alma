package com.example.testlab.ui

import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.testlab.BuildConfig
import com.example.testlab.Graph
import com.example.testlab.data.InstalledApp
import com.example.testlab.data.IntegrityInfo
import com.example.testlab.data.Settings
import com.example.testlab.domain.AdLoadScenario
import com.example.testlab.domain.IntegrityOverride
import com.example.testlab.domain.Product
import com.example.testlab.domain.PurchaseScenario
import com.example.testlab.domain.RecordsState
import com.example.testlab.domain.ShopItem
import com.example.testlab.domain.TestStatus
import com.example.testlab.domain.WalletAction
import com.example.testlab.domain.WalletState
import com.example.testlab.domain.evaluateIntegrity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
inline fun <reified T : ViewModel> rememberVm(crossinline create: () -> T): T =
    viewModel(factory = viewModelFactory { initializer { create() } })

private fun newTxnId() = "SIM-" + UUID.randomUUID().toString().take(8)

// ---------- Uygulamalar + toplu test ----------

class AppsViewModel(private val g: Graph) : ViewModel() {
    private val apps = MutableStateFlow<List<InstalledApp>>(emptyList())
    private val _loading = MutableStateFlow(true)
    private val _query = MutableStateFlow("")
    private val _notice = MutableStateFlow<String?>(null)

    val loading: StateFlow<Boolean> = _loading.asStateFlow()
    val query: StateFlow<String> = _query.asStateFlow()
    val notice: StateFlow<String?> = _notice.asStateFlow()
    val records: StateFlow<RecordsState> = g.records.state

    val visible: StateFlow<List<InstalledApp>> = combine(apps, _query) { list, q ->
        val t = q.trim().lowercase()
        if (t.isEmpty()) list else list.filter { it.label.lowercase().contains(t) || it.packageName.lowercase().contains(t) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            _loading.value = true
            apps.value = g.apps.loadLaunchableApps()
            _loading.value = false
        }
    }

    fun setQuery(q: String) { _query.value = q }
    fun toggle(app: InstalledApp) = g.records.toggle(app.packageName, app.label)
    fun selectAllVisible() = g.records.selectAll(visible.value.map { it.packageName to it.label })
    fun clearSelection() = g.records.clearSelection()
    fun isInstalled(pkg: String) = g.apps.isInstalled(pkg)
    fun saveRecord(pkg: String, status: TestStatus, note: String) = g.records.save(pkg, status, note)

    fun open(pkg: String) {
        _notice.value = if (g.apps.open(pkg)) null else "Uygulama açılamadı (başlatılabilir ekranı yok, kaldırılmış veya görünür değil)."
    }
}

// ---------- Test satın alma + altın ----------

class StoreViewModel(private val g: Graph) : ViewModel() {
    val wallet: StateFlow<WalletState> = g.wallet.state
    val settings: StateFlow<Settings> = g.settings.state

    private val _message = MutableStateFlow<Pair<Boolean, String>?>(null)
    val message: StateFlow<Pair<Boolean, String>?> = _message.asStateFlow()

    fun coinsFor(p: Product, s: Settings = g.settings.state.value) = s.coinOverrides[p.id] ?: p.defaultCoins

    fun purchase(p: Product, scenario: PurchaseScenario) = run(WalletAction.Purchase(p, coinsFor(p), scenario, newTxnId()))
    fun resolvePending(txn: String, success: Boolean) = run(WalletAction.ResolvePending(txn, success))
    fun spend(item: ShopItem) = run(WalletAction.Spend(item))
    fun loseLocal() = run(WalletAction.LoseLocal)
    fun reset() = run(WalletAction.Reset(g.settings.state.value.initialBalance))
    fun clearMessage() { _message.value = null }

    private fun run(a: WalletAction) {
        val r = g.wallet.apply(a)
        _message.value = r.ok to r.message
    }
}

// ---------- Reklam testi ----------

class AdViewModel(private val g: Graph) : ViewModel() {
    val state = g.ads.state
    val log = g.ads.log
    val impressions = g.ads.impressions
    val settings: StateFlow<Settings> = g.settings.state

    private fun disabledReason(): String? {
        val s = g.settings.state.value
        return when {
            s.adsRemoved -> "Reklamsız test sürümü açık"
            !s.adsEnabled -> "Test reklamları kapalı"
            else -> null
        }
    }

    fun load(sc: AdLoadScenario) { viewModelScope.launch { g.ads.load(sc, disabledReason()) } }
    fun show() = g.ads.show()
    fun close() = g.ads.close()
    fun resetAds() = g.ads.reset()
    fun setAdsEnabled(v: Boolean) = g.settings.update { it.copy(adsEnabled = v) }
    fun setAdsRemoved(v: Boolean) = g.settings.update { it.copy(adsRemoved = v) }
}

// ---------- İmza ve bütünlük ----------

class IntegrityViewModel(private val g: Graph) : ViewModel() {
    val info: IntegrityInfo? = runCatching { g.integrity.inspect() }.getOrNull()
    private val _override = MutableStateFlow(IntegrityOverride.REAL)
    val override: StateFlow<IntegrityOverride> = _override.asStateFlow()

    fun expected(s: Settings): String = s.expectedCertOverride.ifBlank { info?.buildExpectedCert.orEmpty() }

    val result = combine(_override, g.settings.state) { o, s ->
        evaluateIntegrity(info?.certSha256.orEmpty(), expected(s), o, BuildConfig.DEBUG)
    }.stateIn(
        viewModelScope, SharingStarted.Eagerly,
        evaluateIntegrity(info?.certSha256.orEmpty(), "", IntegrityOverride.REAL, BuildConfig.DEBUG),
    )

    val settings: StateFlow<Settings> = g.settings.state
    fun setOverride(o: IntegrityOverride) { _override.value = o }
}

// ---------- Geçmiş ve ayarlar ----------

class HistoryViewModel(g: Graph) : ViewModel() {
    val wallet: StateFlow<WalletState> = g.wallet.state
    val records: StateFlow<RecordsState> = g.records.state
}

class SettingsViewModel(private val g: Graph) : ViewModel() {
    val settings: StateFlow<Settings> = g.settings.state
    fun update(t: (Settings) -> Settings) = g.settings.update(t)
}

class HomeViewModel(g: Graph) : ViewModel() {
    val wallet: StateFlow<WalletState> = g.wallet.state
    val records: StateFlow<RecordsState> = g.records.state
}
