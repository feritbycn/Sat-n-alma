package com.example.testlab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.testlab.ui.AdViewModel
import com.example.testlab.ui.AdsScreen
import com.example.testlab.ui.AppTheme
import com.example.testlab.ui.AppsScreen
import com.example.testlab.ui.AppsViewModel
import com.example.testlab.ui.BulkScreen
import com.example.testlab.ui.HistoryScreen
import com.example.testlab.ui.HistoryViewModel
import com.example.testlab.ui.HomeScreen
import com.example.testlab.ui.HomeViewModel
import com.example.testlab.ui.IntegrityScreen
import com.example.testlab.ui.IntegrityViewModel
import com.example.testlab.ui.PurchaseScreen
import com.example.testlab.ui.Screen
import com.example.testlab.ui.SettingsScreen
import com.example.testlab.ui.SettingsViewModel
import com.example.testlab.ui.StoreViewModel
import com.example.testlab.ui.WalletScreen
import com.example.testlab.ui.rememberVm

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val g = (application as TestLabApp).graph
        setContent {
            val settings by g.settings.state.collectAsStateWithLifecycle()
            AppTheme(settings.themeMode) { Root(g) }
        }
    }
}

@Composable
private fun Root(g: Graph) {
    var current by rememberSaveable { mutableStateOf(Screen.HOME.name) }
    val screen = Screen.entries.firstOrNull { it.name == current } ?: Screen.HOME
    fun go(s: Screen) { current = s.name }

    // Geri tuşu: Toplu panel → Uygulamalar, diğer ekranlar → Ana ekran.
    BackHandler(enabled = screen != Screen.HOME) {
        go(if (screen == Screen.BULK) Screen.APPS else Screen.HOME)
    }

    when (screen) {
        Screen.HOME -> HomeScreen(rememberVm { HomeViewModel(g) }, ::go)
        Screen.APPS -> AppsScreen(rememberVm { AppsViewModel(g) }, { go(Screen.HOME) }, { go(Screen.BULK) })
        Screen.BULK -> BulkScreen(rememberVm { AppsViewModel(g) }, { go(Screen.APPS) }, { go(Screen.HISTORY) })
        Screen.PURCHASE -> PurchaseScreen(rememberVm { StoreViewModel(g) }) { go(Screen.HOME) }
        Screen.WALLET -> WalletScreen(rememberVm { StoreViewModel(g) }) { go(Screen.HOME) }
        Screen.ADS -> AdsScreen(rememberVm { AdViewModel(g) }) { go(Screen.HOME) }
        Screen.INTEGRITY -> IntegrityScreen(rememberVm { IntegrityViewModel(g) }) { go(Screen.HOME) }
        Screen.HISTORY -> HistoryScreen(rememberVm { HistoryViewModel(g) }) { go(Screen.HOME) }
        Screen.SETTINGS -> SettingsScreen(rememberVm { SettingsViewModel(g) }) { go(Screen.HOME) }
    }
}
