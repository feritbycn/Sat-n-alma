package com.example.testlab.domain

import org.json.JSONArray
import org.json.JSONObject

/**
 * SİMÜLASYON cüzdanı. Bu uygulamanın kendi demo bakiyesidir: gerçek para, Google Play kaydı,
 * token veya makbuz içermez ve başka bir uygulamaya altın/paket yüklemez.
 */
enum class EntryType(val label: String) {
    PURCHASE("Test satın alma"),
    PENDING("Bekleyen satın alma"),
    PENDING_RESOLVED("Bekleyen sonuçlandı"),
    RESTORE("Geri yükleme"),
    SPEND("Harcama"),
    LOCAL_LOSS("Yerel veri kaybı (simüle)"),
    RESET("Sıfırlama"),
}

data class PendingPurchase(val txnId: String, val productId: String, val coins: Int, val time: Long)

data class HistoryEntry(
    val id: String,
    val time: Long,
    val type: EntryType,
    val productId: String?,
    val result: String,
    val delta: Int,
    val balanceAfter: Int,
)

data class WalletState(
    val balance: Int = 0,
    val ownedPacks: Set<String> = emptySet(),
    /** "Sunucu tarafında" kayıtlı sayılan paketler: geri yüklemede kullanılır. */
    val restorablePacks: Set<String> = emptySet(),
    /** Altınla alınan demo öğeleri: id → adet. */
    val inventory: Map<String, Int> = emptyMap(),
    val pending: List<PendingPurchase> = emptyList(),
    /** En yeni başta. */
    val history: List<HistoryEntry> = emptyList(),
)

sealed interface WalletAction {
    data class Purchase(val product: Product, val coins: Int, val scenario: PurchaseScenario, val txnId: String) : WalletAction
    data class ResolvePending(val txnId: String, val success: Boolean) : WalletAction
    data class Spend(val item: ShopItem) : WalletAction
    data object LoseLocal : WalletAction
    data class Reset(val initialBalance: Int) : WalletAction
}

data class WalletResult(val state: WalletState, val ok: Boolean, val message: String)

object WalletEngine {
    private const val MAX_HISTORY = 200

    private fun add(s: WalletState, e: HistoryEntry) = s.copy(history = (listOf(e) + s.history).take(MAX_HISTORY))

    private fun reject(s: WalletState, msg: String) = WalletResult(s, false, msg)

    fun reduce(s: WalletState, a: WalletAction, now: Long): WalletResult = when (a) {
        is WalletAction.Purchase -> purchase(s, a, now)
        is WalletAction.ResolvePending -> resolve(s, a, now)

        is WalletAction.Spend -> {
            val c = a.item.cost
            if (s.balance < c) {
                reject(s, "Yetersiz bakiye: ${a.item.title} için $c altın gerekli, bakiyeniz ${s.balance}.")
            } else {
                val bal = s.balance - c
                val next = s.copy(balance = bal, inventory = s.inventory + (a.item.id to ((s.inventory[a.item.id] ?: 0) + 1)))
                WalletResult(
                    add(next, HistoryEntry("SPEND-$now", now, EntryType.SPEND, a.item.id, "${a.item.title} alındı", -c, bal)),
                    true,
                    "${a.item.title} alındı. Kalan bakiye: $bal altın.",
                )
            }
        }

        WalletAction.LoseLocal -> WalletResult(
            add(s.copy(ownedPacks = emptySet()), HistoryEntry("LOSS-$now", now, EntryType.LOCAL_LOSS, null, "Yerel paket yetkileri silindi", 0, s.balance)),
            true,
            "Yerel paket yetkileri silindi (simülasyon). Bakiye korundu; 'Geri yükle' senaryosunu deneyin.",
        )

        is WalletAction.Reset -> WalletResult(
            WalletState(
                balance = a.initialBalance,
                history = listOf(HistoryEntry("RESET-$now", now, EntryType.RESET, null, "Test bakiyesi sıfırlandı", 0, a.initialBalance)),
            ),
            true,
            "Cüzdan sıfırlandı. Başlangıç bakiyesi: ${a.initialBalance} altın.",
        )
    }

    /** Başarılı teslimat: altın ekler, paketse sahipliği işler. Paket zaten varsa dokunmaz. */
    private fun grant(s: WalletState, p: Product, coins: Int, txn: String, type: EntryType, now: Long): WalletResult {
        if (p.kind == ProductKind.PACK && p.id in s.ownedPacks) {
            return WalletResult(
                add(s, HistoryEntry(txn, now, type, p.id, "Zaten sahip", 0, s.balance)),
                false,
                "${p.title}: zaten sahipsiniz.",
            )
        }
        val bal = s.balance + coins
        val next = s.copy(
            balance = bal,
            ownedPacks = if (p.kind == ProductKind.PACK) s.ownedPacks + p.id else s.ownedPacks,
            restorablePacks = if (p.kind == ProductKind.PACK) s.restorablePacks + p.id else s.restorablePacks,
        )
        return WalletResult(
            add(next, HistoryEntry(txn, now, type, p.id, "Başarılı (simülasyon)", coins, bal)),
            true,
            "${p.title}: başarılı (simülasyon)" + if (coins > 0) ". +$coins altın, bakiye $bal." else ".",
        )
    }

    private fun purchase(s: WalletState, a: WalletAction.Purchase, now: Long): WalletResult {
        val p = a.product
        // Yinelenen olay koruması: aynı işlem kimliği + tür iki kez uygulanmaz (çift altın verilmez).
        if (s.history.any { it.id == a.txnId && it.type == EntryType.PURCHASE }) {
            return WalletResult(s, true, "Yinelenen işlem yok sayıldı (${a.txnId}).")
        }
        return when (a.scenario) {
            PurchaseScenario.SUCCESS -> grant(s, p, a.coins, a.txnId, EntryType.PURCHASE, now)

            PurchaseScenario.USER_CANCELED -> WalletResult(
                add(s, HistoryEntry(a.txnId, now, EntryType.PURCHASE, p.id, "Kullanıcı iptal etti", 0, s.balance)),
                true, "${p.title}: kullanıcı iptal etti (simülasyon). Bakiye değişmedi.",
            )

            PurchaseScenario.PAYMENT_ERROR -> WalletResult(
                add(s, HistoryEntry(a.txnId, now, EntryType.PURCHASE, p.id, "Ödeme hatası", 0, s.balance)),
                true, "${p.title}: ödeme hatası (simülasyon). Bakiye değişmedi.",
            )

            PurchaseScenario.ALREADY_OWNED -> WalletResult(
                add(s, HistoryEntry(a.txnId, now, EntryType.PURCHASE, p.id, "Zaten sahip (simüle)", 0, s.balance)),
                true, "${p.title}: ürün zaten satın alınmış görünüyor (simülasyon). Altın verilmedi.",
            )

            PurchaseScenario.PENDING -> WalletResult(
                add(
                    s.copy(pending = s.pending + PendingPurchase(a.txnId, p.id, a.coins, now)),
                    HistoryEntry(a.txnId, now, EntryType.PENDING, p.id, "Beklemede", 0, s.balance),
                ),
                true, "${p.title}: işlem beklemede. Tamamlanana kadar altın/paket verilmez.",
            )

            PurchaseScenario.RESTORE -> {
                val restored = s.restorablePacks - s.ownedPacks
                WalletResult(
                    add(
                        s.copy(ownedPacks = s.ownedPacks + s.restorablePacks),
                        HistoryEntry(a.txnId, now, EntryType.RESTORE, null, "${restored.size} paket geri yüklendi", 0, s.balance),
                    ),
                    true, "${restored.size} paket geri yüklendi / tekrar doğrulandı. Altın bakiyesi değişmez.",
                )
            }
        }
    }

    private fun resolve(s: WalletState, a: WalletAction.ResolvePending, now: Long): WalletResult {
        val p = s.pending.firstOrNull { it.txnId == a.txnId } ?: return reject(s, "Bekleyen işlem bulunamadı.")
        val product = Catalog.product(p.productId) ?: return reject(s, "Bilinmeyen ürün: ${p.productId}")
        val without = s.copy(pending = s.pending - p)
        return if (a.success) {
            grant(without, product, p.coins, p.txnId, EntryType.PENDING_RESOLVED, now)
        } else {
            WalletResult(
                add(without, HistoryEntry(p.txnId, now, EntryType.PENDING_RESOLVED, p.productId, "Bekleyen işlem iptal edildi", 0, s.balance)),
                true, "${product.title}: bekleyen işlem iptal edildi. Bakiye değişmedi.",
            )
        }
    }
}

// ---------- JSON (kalıcı depolama) ----------

fun WalletState.toJson(): JSONObject = JSONObject()
    .put("balance", balance)
    .put("owned", JSONArray(ownedPacks.toList()))
    .put("restorable", JSONArray(restorablePacks.toList()))
    .put("inventory", JSONObject().also { o -> inventory.forEach { (k, v) -> o.put(k, v) } })
    .put("pending", JSONArray(pending.map {
        JSONObject().put("txn", it.txnId).put("product", it.productId).put("coins", it.coins).put("time", it.time)
    }))
    .put("history", JSONArray(history.map {
        JSONObject().put("id", it.id).put("time", it.time).put("type", it.type.name)
            .put("product", it.productId ?: JSONObject.NULL).put("result", it.result)
            .put("delta", it.delta).put("balance", it.balanceAfter)
    }))

fun walletFromJson(o: JSONObject): WalletState {
    fun strings(a: JSONArray?) = (0 until (a?.length() ?: 0)).map { a!!.getString(it) }.toSet()
    val inv = o.optJSONObject("inventory")
    val pend = o.optJSONArray("pending")
    val hist = o.optJSONArray("history")
    return WalletState(
        balance = o.optInt("balance"),
        ownedPacks = strings(o.optJSONArray("owned")),
        restorablePacks = strings(o.optJSONArray("restorable")),
        inventory = inv?.let { o -> o.keys().asSequence().associateWith { k -> o.getInt(k) } } ?: emptyMap(),
        pending = (0 until (pend?.length() ?: 0)).map {
            val p = pend!!.getJSONObject(it)
            PendingPurchase(p.getString("txn"), p.getString("product"), p.getInt("coins"), p.getLong("time"))
        },
        history = (0 until (hist?.length() ?: 0)).mapNotNull {
            val h = hist!!.getJSONObject(it)
            val type = EntryType.entries.firstOrNull { t -> t.name == h.optString("type") } ?: return@mapNotNull null
            HistoryEntry(
                h.getString("id"), h.getLong("time"), type,
                if (h.isNull("product")) null else h.getString("product"),
                h.optString("result"), h.optInt("delta"), h.optInt("balance"),
            )
        },
    )
}
