package com.example.testlab.data

import android.app.Activity
import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.example.testlab.domain.PurchaseScenario

/**
 * Test bakiyesini KENDİ debug oyununuza iletir. Korumalar:
 *  - Yayın, imza düzeyinde izinle korunur: yalnızca Test Lab ile aynı anahtarla imzalı uygulama alabilir.
 *  - Hedef uygulama "debuggable" değilse gönderilmez (yayın/release sürümlere asla gönderilmez).
 *  - Alıcı onaylamazsa (setResultCode(RESULT_OK)) sonuç "onay yok" olarak gösterilir; başarı varsayılmaz.
 * Bu bir simülasyondur: Google Play, token veya makbuz içermez.
 */
class GameLink(private val app: Application) {
    companion object {
        const val ACTION = "com.example.testlab.action.TEST_EVENT"
        const val PERMISSION = "com.example.testlab.permission.SEND_TEST_EVENT"
    }

    /** Test Lab'ın simülasyon bakiyesini/paketlerini hedef debug uygulamaya iletir. */
    fun send(targetPackage: String, balance: Int, packs: Set<String>, onResult: (Boolean, String) -> Unit) {
        dispatch(targetPackage, onResult, "Bakiye $balance, ${packs.size} paket") {
            putExtra("type", "BALANCE")
            putExtra("balance", balance)
            putStringArrayListExtra("packs", ArrayList(packs.sorted()))
        }
    }

    /** Hedef (kendi) debug uygulamada SİMÜLE satın alma senaryosunu tetikler. Gerçek ödeme yapılmaz. */
    fun sendPurchase(targetPackage: String, productId: String, scenario: PurchaseScenario, onResult: (Boolean, String) -> Unit) {
        val wire = when (scenario) {
            PurchaseScenario.SUCCESS -> "SUCCESS"
            PurchaseScenario.USER_CANCELED -> "CANCEL"
            PurchaseScenario.PAYMENT_ERROR -> "ERROR"
            PurchaseScenario.ALREADY_OWNED -> "OWNED"
            PurchaseScenario.PENDING -> "PENDING"
            PurchaseScenario.RESTORE -> "RESTORE"
        }
        dispatch(targetPackage, onResult, "${scenario.label} / $productId") {
            putExtra("type", "PURCHASE")
            putExtra("productId", productId)
            putExtra("scenario", wire)
        }
    }

    private fun dispatch(targetPackage: String, onResult: (Boolean, String) -> Unit, what: String, fill: Intent.() -> Unit) {
        val pkg = targetPackage.trim()
        try {
            app.packageManager.getApplicationInfo(pkg, 0).also { info ->
                if (info.flags and ApplicationInfo.FLAG_DEBUGGABLE == 0) {
                    return onResult(false, "Reddedildi: hedef uygulama debug sürüm değil. Test olayları yalnızca debug derlemelere gönderilir.")
                }
            }
        } catch (e: PackageManager.NameNotFoundException) {
            return onResult(false, "Paket bulunamadı veya görünür değil: $pkg")
        }
        val intent = Intent(ACTION).apply {
            setPackage(pkg)
            putExtra("source", "TestLab-simulation")
            putExtra("sentAt", System.currentTimeMillis())
            fill()
        }
        val done = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, i: Intent?) {
                if (resultCode == Activity.RESULT_OK) {
                    onResult(true, "Uygulama onayladı ($what). ${resultData.orEmpty()}".trim())
                } else {
                    onResult(
                        false,
                        "Onay yok. Uygulamada alıcı kod yok, imza anahtarı aynı değil (izin verilmedi) veya uygulama debug değil (docs/OYUN_ENTEGRASYONU.md).",
                    )
                }
            }
        }
        try {
            app.sendOrderedBroadcast(intent, PERMISSION, done, null, Activity.RESULT_CANCELED, null, null)
        } catch (e: Exception) {
            onResult(false, "Gönderilemedi: ${e.javaClass.simpleName}")
        }
    }
}
