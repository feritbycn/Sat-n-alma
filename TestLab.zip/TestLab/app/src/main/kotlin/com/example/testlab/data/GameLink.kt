package com.example.testlab.data

import android.app.Activity
import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

/**
 * Test bakiyesini KENDİ debug oyununuza iletir. Korumalar:
 *  - Yayın, imza düzeyinde izinle korunur: yalnızca Test Lab ile aynı anahtarla imzalı uygulama alabilir.
 *  - Hedef uygulama "debuggable" değilse gönderilmez (yayın/release sürümlere asla gönderilmez).
 *  - Alıcı onaylamazsa (setResultCode(RESULT_OK)) sonuç "onay yok" olarak gösterilir; başarı varsayılmaz.
 * Bu bir simülasyondur: Google Play, token veya makbuz içermez.
 */
class GameLink(private val app: Application) {
    companion object {
        const val ACTION = "com.example.testlab.action.TEST_EVENT"
        const val PERMISSION = "com.example.testlab.permission.SEND_TEST_EVENT"
    }

    fun send(targetPackage: String, balance: Int, packs: Set<String>, onResult: (Boolean, String) -> Unit) {
        val pkg = targetPackage.trim()
        val info = try {
            app.packageManager.getApplicationInfo(pkg, 0)
        } catch (e: PackageManager.NameNotFoundException) {
            return onResult(false, "Paket bulunamadı veya görünür değil: $pkg")
        }
        if (info.flags and ApplicationInfo.FLAG_DEBUGGABLE == 0) {
            return onResult(false, "Reddedildi: hedef uygulama debug sürüm değil. Test olayları yalnızca debug derlemelere gönderilir.")
        }
        val intent = Intent(ACTION).apply {
            setPackage(pkg)
            putExtra("source", "TestLab-simulation")
            putExtra("balance", balance)
            putStringArrayListExtra("packs", ArrayList(packs.sorted()))
            putExtra("sentAt", System.currentTimeMillis())
        }
        val done = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, i: Intent?) {
                if (resultCode == Activity.RESULT_OK) {
                    onResult(true, "Oyun onayladı: bakiye $balance, ${packs.size} paket gönderildi (simülasyon).")
                } else {
                    onResult(
                        false,
                        "Onay yok. Oyunda alıcı kod yok, izin/imza uyuşmuyor veya oyun kapalı olabilir (docs/OYUN_ENTEGRASYONU.md).",
                    )
                }
            }
        }
        try {
            app.sendOrderedBroadcast(intent, PERMISSION, done, null, Activity.RESULT_CANCELED, null, null)
        } catch (e: Exception) {
            onResult(false, "Gönderilemedi: ${e.javaClass.simpleName}")
        }
    }
}
