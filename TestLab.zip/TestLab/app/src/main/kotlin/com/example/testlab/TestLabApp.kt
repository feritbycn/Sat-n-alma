package com.example.testlab

import android.app.Application
import com.example.testlab.data.AppRepository
import com.example.testlab.data.IntegrityInspector
import com.example.testlab.data.JsonPrefs
import com.example.testlab.data.RecordsRepository
import com.example.testlab.data.SettingsRepository
import com.example.testlab.data.WalletRepository
import com.example.testlab.domain.AdEngine

/** Basit elle bağımlılık enjeksiyonu (prototip için yeterli). */
class Graph(app: Application) {
    private val prefs = JsonPrefs(app)
    val settings = SettingsRepository(prefs)
    val wallet = WalletRepository(prefs)
    val records = RecordsRepository(prefs)
    val apps = AppRepository(app)
    val integrity = IntegrityInspector(app)
    val ads = AdEngine()
}

class TestLabApp : Application() {
    lateinit var graph: Graph
        private set

    override fun onCreate() {
        super.onCreate()
        graph = Graph(this)
    }
}
