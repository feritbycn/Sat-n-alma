package com.example.testlab.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.testlab.domain.Catalog
import com.example.testlab.domain.ProductKind
import com.example.testlab.domain.PurchaseScenario

@Composable
fun PurchaseScreen(vm: StoreViewModel, onBack: () -> Unit) {
    val wallet by vm.wallet.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    var selectedId by remember { mutableStateOf(Catalog.products.first().id) }
    var scenario by remember { mutableStateOf(PurchaseScenario.SUCCESS) }

    ScreenScaffold("Test satın alma", onBack) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                SimBanner(
                    "SİMÜLASYON MODU: Gerçek para harcanmaz, Google Play işlemi yapılmaz; token veya makbuz üretilmez. " +
                        "Sonuçlar yalnızca bu uygulamanın test bakiyesine yazılır.",
                )
            }
            item {
                Text("Mod", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = true, onClick = {}, label = { Text("Simülasyon") })
                    FilterChip(selected = false, onClick = {}, enabled = false, label = { Text("Gerçek Google Play Billing") })
                }
                Text(
                    "Gerçek Billing bu sürümde YAPILANDIRILMAMIŞTIR (Play Console, ürünler ve test kullanıcıları gerekir). Bkz. README.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            item { Text("Senaryo", style = MaterialTheme.typography.titleSmall) }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(PurchaseScenario.entries) { s ->
                        FilterChip(selected = scenario == s, onClick = { scenario = s }, label = { Text(s.label) })
                    }
                }
            }
            item { Text("Ürünler", style = MaterialTheme.typography.titleSmall) }
            items(Catalog.products, key = { it.id }) { p ->
                val coins = vm.coinsFor(p, settings)
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = selectedId == p.id, onClick = { selectedId = p.id })
                        Column(Modifier.weight(1f)) {
                            Text(p.title, style = MaterialTheme.typography.titleSmall)
                            Text(
                                "${p.testPrice} · kimlik: ${p.id}\n" +
                                    (if (p.kind == ProductKind.GOLD) "tüketilebilir" else "kalıcı paket") +
                                    (if (coins > 0) " · +$coins altın" else "") +
                                    (if (p.id in wallet.ownedPacks) " · SAHİPSİNİZ" else ""),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
            item {
                Button(
                    onClick = { Catalog.product(selectedId)?.let { vm.purchase(it, scenario) } },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Test Satın Al (${scenario.label})") }
            }
            message?.let { (ok, text) -> item { MessageCard(ok, text) } }

            if (wallet.pending.isNotEmpty()) {
                item { Text("Bekleyen işlemler", style = MaterialTheme.typography.titleSmall) }
                items(wallet.pending, key = { it.txnId }) { p ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${Catalog.title(p.productId)}\n${p.txnId}", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { vm.resolvePending(p.txnId, true) }) { Text("Tamamla") }
                        OutlinedButton(onClick = { vm.resolvePending(p.txnId, false) }) { Text("İptal") }
                    }
                }
            }
            item {
                OutlinedButton(onClick = vm::loseLocal, modifier = Modifier.fillMaxWidth()) {
                    Text("Yerel paket yetkilerini sil (veri kaybı simülasyonu)")
                }
                Text(
                    "Ardından 'Geri yükle / tekrar doğrula' senaryosuyla paketleri geri getirin. Altın bakiyesi bundan etkilenmez.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
fun WalletScreen(vm: StoreViewModel, onBack: () -> Unit) {
    val wallet by vm.wallet.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    var confirmReset by remember { mutableStateOf(false) }

    ScreenScaffold("Altın ve paketler", onBack) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                SimBanner(
                    "Bu bakiye bu uygulamanın kendi TEST bakiyesidir (simülasyon). Başka bir uygulamaya altın veya paket yüklenmez.",
                )
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Güncel altın bakiyesi", style = MaterialTheme.typography.labelMedium)
                        Text("${wallet.balance}", style = MaterialTheme.typography.displaySmall)
                    }
                }
            }
            message?.let { (ok, text) -> item { MessageCard(ok, text) } }

            item { Text("Altınla harca (demo öğeleri)", style = MaterialTheme.typography.titleSmall) }
            items(Catalog.shopItems, key = { it.id }) { item ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.title)
                        Text("${item.cost} altın · envanterde: ${wallet.inventory[item.id] ?: 0}", style = MaterialTheme.typography.bodySmall)
                    }
                    Button(onClick = { vm.spend(item) }) { Text("Satın al") }
                }
            }

            item { Text("Sahip olunan paketler", style = MaterialTheme.typography.titleSmall) }
            if (wallet.ownedPacks.isEmpty()) item { Text("Henüz paket yok. 'Test satın alma' ekranından paket alın.") }
            items(wallet.ownedPacks.toList(), key = { it }) { id -> Text("✓ ${Catalog.title(id)}  ($id)") }

            item {
                OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Test bakiyesini sıfırla")
                }
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Sıfırlansın mı?") },
            text = { Text("Bakiye başlangıç değerine döner; paketler, envanter ve bekleyen işlemler silinir. Geçmişe bir sıfırlama kaydı eklenir.") },
            confirmButton = { TextButton(onClick = { vm.reset(); confirmReset = false }) { Text("Sıfırla") } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Vazgeç") } },
        )
    }
}
