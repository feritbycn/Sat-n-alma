package com.example.testlab.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Build
import com.example.testlab.BuildConfig
import com.example.testlab.domain.colonFormat
import com.example.testlab.domain.sha256Hex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class InstalledApp(val packageName: String, val label: String, val isSystem: Boolean)

/**
 * Yalnızca Android'in herkese açık PackageManager API'leri. Başka uygulamaların özel verilerine,
 * dosyalarına veya APK'larına erişilmez; hiçbir şey değiştirilmez. Görünürlük manifestteki <queries> ile
 * sınırlıdır (QUERY_ALL_PACKAGES yok): yalnızca başlatıcıda görünen uygulamalar listelenir.
 */
class AppRepository(private val context: Context) {
    private val pm: PackageManager = context.packageManager

    suspend fun loadLaunchableApps(): List<InstalledApp> = withContext(Dispatchers.Default) {
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        queryActivities(launcher)
            .map { it.activityInfo.packageName }
            .distinct()
            .filter { it != context.packageName }
            .mapNotNull { pkg ->
                runCatching {
                    val ai = appInfo(pkg)
                    InstalledApp(pkg, ai.loadLabel(pm).toString(), ai.flags and ApplicationInfo.FLAG_SYSTEM != 0)
                }.getOrNull()
            }
            .sortedBy { it.label.lowercase() }
    }

    /** Paket görünür ve yüklü mü? Görünmeyen/kaldırılmış paketler için false. */
    fun isInstalled(pkg: String): Boolean = runCatching { appInfo(pkg) }.isSuccess

    /** Android'in kendi başlatma intent'iyle uygulamayı açar. */
    fun open(pkg: String): Boolean {
        val intent = pm.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) ?: return false
        return runCatching { context.startActivity(intent) }.isSuccess
    }

    @Suppress("DEPRECATION")
    private fun appInfo(pkg: String): ApplicationInfo =
        if (Build.VERSION.SDK_INT >= 33) pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0L))
        else pm.getApplicationInfo(pkg, 0)

    @Suppress("DEPRECATION")
    private fun queryActivities(intent: Intent): List<ResolveInfo> =
        if (Build.VERSION.SDK_INT >= 33) pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        else pm.queryIntentActivities(intent, 0)
}

/** KENDİ uygulamanın imza ve bütünlük bilgisi. */
data class IntegrityInfo(
    val packageName: String,
    val versionName: String?,
    val versionCode: Long,
    val debuggableApp: Boolean,
    val debugBuild: Boolean,
    val installer: String?,
    val certSha256: List<String>,
    val multipleSigners: Boolean,
    val buildExpectedCert: String,
)

class IntegrityInspector(private val context: Context) {
    @Suppress("DEPRECATION")
    fun inspect(): IntegrityInfo {
        val pm = context.packageManager
        val pkg = context.packageName
        val info = if (Build.VERSION.SDK_INT >= 33) {
            pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(PackageManager.GET_SIGNING_CERTIFICATES.toLong()))
        } else if (Build.VERSION.SDK_INT >= 28) {
            pm.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES)
        } else {
            pm.getPackageInfo(pkg, PackageManager.GET_SIGNATURES)
        }

        val signers = if (Build.VERSION.SDK_INT >= 28) {
            info.signingInfo?.apkContentsSigners?.toList().orEmpty()
        } else {
            info.signatures?.toList().orEmpty()
        }
        val multi = if (Build.VERSION.SDK_INT >= 28) info.signingInfo?.hasMultipleSigners() == true else signers.size > 1

        val installer = runCatching {
            if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName
            else pm.getInstallerPackageName(pkg)
        }.getOrNull()

        val versionCode = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
        return IntegrityInfo(
            packageName = pkg,
            versionName = info.versionName,
            versionCode = versionCode,
            debuggableApp = context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0,
            debugBuild = BuildConfig.DEBUG,
            installer = installer,
            // Sertifika parmak izi = sertifikanın (DER) SHA-256 özeti.
            certSha256 = signers.map { colonFormat(sha256Hex(it.toByteArray())) },
            multipleSigners = multi,
            buildExpectedCert = BuildConfig.EXPECTED_CERT_SHA256,
        )
    }
}
