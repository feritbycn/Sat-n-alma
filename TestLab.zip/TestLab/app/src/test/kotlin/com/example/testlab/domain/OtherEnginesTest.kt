package com.example.testlab.domain

import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AdEngineTest {
    private fun engine() = AdEngine(loadDelayMs = 100, clock = { 0L })

    @Test fun loadSuccess_thenShow_thenClose_countsImpression() = runTest {
        val e = engine()
        e.load(AdLoadScenario.SUCCESS, null)
        assertEquals(AdState.Loaded, e.state.value)
        assertTrue(e.show())
        assertEquals(AdState.Showing, e.state.value)
        e.close()
        assertEquals(AdState.Idle, e.state.value)
        assertEquals(1, e.impressions.value)
    }

    @Test fun failureScenarios_endInFailed() = runTest {
        for (sc in listOf(AdLoadScenario.ERROR, AdLoadScenario.NO_FILL, AdLoadScenario.TIMEOUT)) {
            val e = engine()
            e.load(sc, null)
            assertTrue("$sc", e.state.value is AdState.Failed)
        }
    }

    @Test fun disabled_blocksLoading() = runTest {
        val e = engine()
        e.load(AdLoadScenario.SUCCESS, "Reklamsız test sürümü")
        assertTrue(e.state.value is AdState.Disabled)
    }

    @Test fun cannotShowWithoutLoad() {
        val e = engine()
        assertFalse(e.show())
        assertEquals(0, e.impressions.value)
    }
}

class IntegrityTest {
    private val cert = "AA:BB:CC"

    @Test fun sha256_matchesKnownVector() {
        // "abc" için bilinen SHA-256
        assertEquals(
            "BA7816BF8F01CFEA414140DE5DAE2223B00361A396177A9CB410FF61F20015AD",
            sha256Hex("abc".toByteArray()),
        )
    }

    @Test fun colonFormat_andNormalize() {
        assertEquals("AA:BB:CC", colonFormat("AABBCC"))
        assertEquals("AABBCC", normalizeFingerprint("aa:bb cc"))
    }

    @Test fun real_match_mismatch_notConfigured() {
        assertEquals(Verdict.MATCH, evaluateIntegrity(listOf(cert), "aa:bb:cc", IntegrityOverride.REAL, true).verdict)
        assertEquals(Verdict.MISMATCH, evaluateIntegrity(listOf(cert), "11:22", IntegrityOverride.REAL, true).verdict)
        assertEquals(Verdict.NOT_CONFIGURED, evaluateIntegrity(listOf(cert), "", IntegrityOverride.REAL, true).verdict)
    }

    @Test fun debug_override_isSimulated() {
        val r = evaluateIntegrity(listOf(cert), "11:22", IntegrityOverride.FORCE_MATCH, isDebugBuild = true)
        assertEquals(Verdict.MATCH, r.verdict)
        assertTrue(r.simulated)
    }

    @Test fun release_ignoresOverride_andKeepsRealCheck() {
        val r = evaluateIntegrity(listOf(cert), "11:22", IntegrityOverride.FORCE_MATCH, isDebugBuild = false)
        assertEquals(Verdict.MISMATCH, r.verdict)
        assertFalse(r.simulated)
    }
}

class RecordsLogicTest {
    @Test fun toggle_selectAll_clear() {
        var s = RecordsState()
        s = RecordsLogic.toggle(s, "a", "A")
        s = RecordsLogic.selectAll(s, listOf("a" to "A", "b" to "B"))
        assertEquals(listOf("a", "b"), s.selected)
        s = RecordsLogic.toggle(s, "a", "A")
        assertEquals(listOf("b"), s.selected)
        s = RecordsLogic.clear(s)
        assertTrue(s.selected.isEmpty())
    }

    @Test fun save_storesStatusNote_andHistory_andRoundTrips() {
        var s = RecordsLogic.toggle(RecordsState(), "pkg.x", "X")
        s = RecordsLogic.save(s, "pkg.x", TestStatus.FAILED, "  çöktü  ", now = 5)
        s = RecordsLogic.save(s, "pkg.x", TestStatus.SUCCESS, "düzeldi", now = 9)
        assertEquals(TestStatus.SUCCESS, s.records["pkg.x"]!!.status)
        assertEquals(listOf(TestStatus.SUCCESS, TestStatus.FAILED), s.events.map { it.status })
        assertEquals("çöktü", s.events.last().note)
        assertEquals(s, recordsFromJson(s.toJson()))
    }
}
