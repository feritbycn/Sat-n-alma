package com.example.testlab.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WalletEngineTest {
    private var now = 1_000L
    private fun step(s: WalletState, a: WalletAction) = WalletEngine.reduce(s, a, now++)

    private val gold1000 = Catalog.product("gold_1000")!!
    private val starter = Catalog.product("starter_pack")!!
    private val special = Catalog.product("special_test_pack")!!

    private fun buy(s: WalletState, p: Product, sc: PurchaseScenario, txn: String, coins: Int = p.defaultCoins) =
        step(s, WalletAction.Purchase(p, coins, sc, txn))

    @Test fun example_buy1000_spend250_leaves750() {
        var r = buy(WalletState(), gold1000, PurchaseScenario.SUCCESS, "T1")
        assertEquals(1000, r.state.balance)
        r = step(r.state, WalletAction.Spend(ShopItem("x", "Test öğesi", 250)))
        assertTrue(r.ok)
        assertEquals(750, r.state.balance)
    }

    @Test fun configurableAmount_isUsed() {
        val r = buy(WalletState(), gold1000, PurchaseScenario.SUCCESS, "T1", coins = 1234)
        assertEquals(1234, r.state.balance)
    }

    @Test fun cancelAndError_doNotChangeBalance_butAreRecorded() {
        var r = buy(WalletState(), gold1000, PurchaseScenario.USER_CANCELED, "A")
        r = buy(r.state, gold1000, PurchaseScenario.PAYMENT_ERROR, "B")
        assertEquals(0, r.state.balance)
        assertEquals(listOf("Ödeme hatası", "Kullanıcı iptal etti"), r.state.history.map { it.result })
    }

    @Test fun duplicateTransaction_doesNotGrantTwice() {
        var r = buy(WalletState(), gold1000, PurchaseScenario.SUCCESS, "SAME")
        r = buy(r.state, gold1000, PurchaseScenario.SUCCESS, "SAME")
        assertEquals(1000, r.state.balance)
        assertEquals(1, r.state.history.size)
    }

    @Test fun packCannotBeBoughtTwice() {
        var r = buy(WalletState(), starter, PurchaseScenario.SUCCESS, "P1")
        assertEquals(500, r.state.balance)
        assertEquals(setOf("starter_pack"), r.state.ownedPacks)
        r = buy(r.state, starter, PurchaseScenario.SUCCESS, "P2")
        assertFalse(r.ok)
        assertEquals(500, r.state.balance)
    }

    @Test fun alreadyOwnedScenario_grantsNothing() {
        val r = buy(WalletState(), gold1000, PurchaseScenario.ALREADY_OWNED, "A")
        assertEquals(0, r.state.balance)
        assertEquals("Zaten sahip (simüle)", r.state.history.first().result)
    }

    @Test fun pending_grantsNothingUntilResolved() {
        var r = buy(WalletState(), gold1000, PurchaseScenario.PENDING, "PEND")
        assertEquals(0, r.state.balance)
        assertEquals(1, r.state.pending.size)
        r = step(r.state, WalletAction.ResolvePending("PEND", true))
        assertEquals(1000, r.state.balance)
        assertTrue(r.state.pending.isEmpty())
    }

    @Test fun pendingCanBeCanceled() {
        var r = buy(WalletState(), gold1000, PurchaseScenario.PENDING, "PEND")
        r = step(r.state, WalletAction.ResolvePending("PEND", false))
        assertEquals(0, r.state.balance)
        assertTrue(r.state.pending.isEmpty())
    }

    @Test fun restore_bringsPacksBack_withoutChangingBalance() {
        var r = buy(WalletState(), special, PurchaseScenario.SUCCESS, "S1")
        r = buy(r.state, gold1000, PurchaseScenario.SUCCESS, "G1")
        r = step(r.state, WalletAction.LoseLocal)
        assertTrue(r.state.ownedPacks.isEmpty())
        r = buy(r.state, special, PurchaseScenario.RESTORE, "R1")
        assertEquals(setOf("special_test_pack"), r.state.ownedPacks)
        assertEquals(1000, r.state.balance)
    }

    @Test fun insufficientBalance_isRejected_andBalanceKept() {
        val start = WalletState(balance = 100)
        val r = step(start, WalletAction.Spend(ShopItem("sword", "Kılıç", 250)))
        assertFalse(r.ok)
        assertTrue(r.message.contains("Yetersiz bakiye"))
        assertEquals(100, r.state.balance)
    }

    @Test fun reset_restoresInitialBalance_andClearsState() {
        var r = buy(WalletState(), starter, PurchaseScenario.SUCCESS, "P1")
        r = step(r.state, WalletAction.Reset(initialBalance = 300))
        assertEquals(300, r.state.balance)
        assertTrue(r.state.ownedPacks.isEmpty())
        assertEquals(1, r.state.history.size)
    }

    @Test fun jsonRoundTrip_keepsEverything() {
        var r = buy(WalletState(), starter, PurchaseScenario.SUCCESS, "P1")
        r = buy(r.state, gold1000, PurchaseScenario.PENDING, "PEND")
        r = step(r.state, WalletAction.Spend(ShopItem("potion", "İksir", 50)))
        val back = walletFromJson(r.state.toJson())
        assertEquals(r.state, back)
    }
}
