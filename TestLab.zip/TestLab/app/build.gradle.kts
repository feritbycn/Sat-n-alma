plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.testlab"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.testlab"
        minSdk = 26          // Android 8.0
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0"

        val adsOff = providers.gradleProperty("testlab.adsDisabledByDefault").orElse("false").get()
        buildConfigField("boolean", "ADS_DISABLED_BY_DEFAULT", adsOff)
        // Release'te boş: kendi anahtarınızın parmak izini uygulamadaki Ayarlar'dan girin.
        // Debug için aşağıda (buildTypes.debug) doldurulur.
        buildConfigField("String", "EXPECTED_CERT_SHA256", "\"\"")
    }

    // Yalnızca DEBUG: depodaki ortak debug anahtarı. Gizli değildir; release için KULLANMAYIN.
    // Amaç: GitHub Actions'ın her çalışmasında aynı imza, böylece APK'lar birbirinin üzerine kurulur.
    signingConfigs {
        getByName("debug") {
            storeFile = rootProject.file("keystore/debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            buildConfigField("String", "EXPECTED_CERT_SHA256", "\"${providers.gradleProperty("testlab.debugCertSha256").orElse("").get()}\"")
        }
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.09.01")
    implementation(composeBom)
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-compose:1.11.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.4")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.10.2")
    // JVM birim testlerinde gerçek org.json (Android stub'ı çalışmaz)
    testImplementation("org.json:json:20240303")
}
