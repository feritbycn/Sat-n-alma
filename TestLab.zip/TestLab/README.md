# Test Lab — Android test uygulaması (simülasyon)

Kendi geliştirdiğiniz uygulamaları test etmek için çevrimdışı bir araç. **Her satın alma, altın ve reklam sonucu SİMÜLASYONDUR**: gerçek para, Google Play işlemi, token veya makbuz yoktur. Başka uygulamaların APK'sı, reklamı, imzası veya satın alma sistemi değiştirilmez/atlatılmaz.

## Bölümler
Uygulamalar · Test satın alma · Altın ve paketler · Reklam testi · İmza ve bütünlük testi · İşlem geçmişi · Ayarlar (+ Toplu test paneli: Uygulamalar'da "Seçilenleri Test Et").

## Sürümler
Kotlin 2.2.20 · AGP 8.13.0 · Gradle 8.13 · **JDK 17** · Compose BOM 2025.09.01 · minSdk 26 (Android 8.0) · target/compile SDK 36. Paket: `com.example.testlab`. İzin yok (INTERNET dahil).

## Telefondan GitHub ile APK üretme
1. github.com'a giriş yapın → **+ → New repository** → ad verin (örn. `TestLab`) → **Create repository**.
2. ZIP'i telefonda açın (Dosyalar uygulaması → "Çıkar"). Tarayıcıda **masaüstü sitesi** modunu açmanız önerilir.
3. Depoda **Add file → Upload files**; çıkardığınız klasörün **içindeki her şeyi** (`app`, `gradle`, `keystore`, `.github`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `README.md`, `.gitignore`) yükleyin. Not: `.github` gizli klasördür; mobilde görünmezse dosya yöneticisinde "gizli dosyaları göster"i açın. Alternatif: GitHub'da **Add file → Create new file** ile `.github/workflows/android-apk.yml` adını yazıp dosya içeriğini yapıştırın.
4. **Commit changes** (main dalına).
5. **Actions** sekmesi → "Android APK" çalışır (ilk seferde "I understand my workflows, enable them" çıkabilir). Elle başlatmak için: Actions → Android APK → **Run workflow**.
6. Yeşil tik olunca çalıştırmanın içinde **Artifacts → TestLab-debug-apk** indirin (ZIP gelir, içinden `app-debug.apk` çıkarın).
7. APK'ya dokunun → "Bilinmeyen kaynaklardan yüklemeye izin ver" → Kur.

Workflow dosyası: `.github/workflows/android-apk.yml`. Gizli anahtar veya ücretli servis gerekmez. `v1.0` gibi bir etiket (tag) iterseniz APK ayrıca Releases'e eklenir.

## Derleme hata verirse
Actions → başarısız çalıştırma → kırmızı adım → günlüğü açın. **Bu kod yazıldığı ortamda hiç derlenmedi** (Android SDK yoktu); ilk gerçek derleme GitHub'da olur. Hata olursa günlükteki `e:` ile başlayan satırları bana yapıştırın. Sık nedenler:
- `.github` klasörü yüklenmediği için Actions hiç çalışmaz → 3. adımı kontrol edin.
- `keystore/debug.keystore` yüklenmediyse imza hatası olur (`.gitignore` istisnası eklidir; web yüklemesinde dosyanın gerçekten yüklendiğine bakın).
- SDK/lisans hatası → "Android SDK paketleri" adımının günlüğüne bakın.
- Sürüm bulunamadı (AGP/Kotlin/BOM) → `settings.gradle.kts` ve `app/build.gradle.kts` içindeki sürümleri güncelleyin.

## Simülasyon ve gerçek Billing
| Konu | Bu uygulamada | Gerçek için gerekenler |
|---|---|---|
| Satın alma akışı (başarılı, iptal, hata, sahip, bekleyen, geri yükleme) | Simülasyon, çevrimdışı | Play Console'da uygulama + ürünler, Play'e yüklenmiş sürüm, lisans test kullanıcıları |
| Gerçek ödeme/makbuz/token | **Yok, üretilmez** | Play Billing Library + sunucu tarafı doğrulama (Google Play Developer API) |
| Gerçek reklam | **Yok** (SDK eklenmemiş) | Reklam SDK'sı ve kendi reklam birimi kimlikleriniz |
| İmza testi | Gerçek: kendi APK'nızın imza parmak izi okunur | Release için kendi anahtarınız |

Gerçek Billing eklenecekse: `app/build.gradle.kts` (bağımlılık `com.android.billingclient:billing-ktx`), yeni `data/BillingRepository.kt`, `ui/Viewmodels.kt` (StoreViewModel'e bağlama) ve `ui/StoreScreens.kt` ("Gerçek Google Play Billing" çipi şu an devre dışı). Gerçek ürün/test kullanıcısı gerektiren testler: gerçek satın alma, abonelik, iade, bekleyen ödeme yöntemleri; simülasyonla denenebilenler: arayüz akışları, bakiye mantığı, çift işlem koruması.

## İmza notu
Debug APK'lar depodaki ortak `keystore/debug.keystore` ile imzalanır (herkesçe bilinen test anahtarı, gizli değil) — böylece her CI derlemesi aynı imzayı taşır ve üzerine güncelleme kurulabilir. Release imzası için **kendi** anahtarınızı üretin ve depoya koymayın.

## Testler
`gradle :app:testDebugUnitTest` — cüzdan (1000 → 250 harca → 750, çift işlem, bekleyen, geri yükleme, sıfırlama), reklam, imza ve kayıt mantığı.
