// Sürümler sabitlenmiştir: AGP 8.13.0 → Gradle 8.13 + JDK 17 gerektirir.
plugins {
    id("com.android.application") version "8.13.0" apply false
    id("org.jetbrains.kotlin.android") version "2.2.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.20" apply false
}
