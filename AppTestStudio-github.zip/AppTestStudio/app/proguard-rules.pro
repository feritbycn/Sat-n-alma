# Ek kural gerekmez.
