package com.example.apptest.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.apptest.AppGraph
import com.example.apptest.data.AppDetails
import com.example.apptest.data.installerLabel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AppDetailScreen(graph: AppGraph, packageName: String, onBack: () -> Unit) {
    val vm: AppDetailViewModel = viewModel(
        key = "detail-$packageName",
        factory = viewModelFactory { initializer { AppDetailViewModel(graph, packageName) } },
    )
    val state by vm.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val d = state.details

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onBack) { Text("‹ Geri") }
            AppIcon(packageName, 40.dp)
            Column(Modifier.weight(1f)) {
                Text(d?.label ?: packageName, style = MaterialTheme.typography.titleLarge, maxLines = 1)
                Text(packageName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Bilgi") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Test merkezi") })
        }
        when {
            state.loading -> CircularProgressIndicator(Modifier.padding(24.dp))
            d == null -> Text("Bu uygulamanın bilgileri okunamadı (kaldırılmış veya görünür değil).", Modifier.padding(16.dp))
            tab == 0 -> InfoTab(d, canOpen = d.canOpen, openFailed = state.openFailed, onOpen = vm::open)
            else -> TestCenterScreen(graph, packageName, d.label)
        }
    }
}

@Composable
private fun InfoTab(d: AppDetails, canOpen: Boolean, openFailed: Boolean, onOpen: () -> Unit) {
    val fmt = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
    val rows = buildList {
        add("Uygulama adı" to d.label)
        add("Paket adı" to d.packageName)
        add("Sürüm" to "${d.versionName ?: "—"} (kod ${d.versionCode})")
        add("İlk kurulum" to fmt.format(Date(d.firstInstallTime)))
        add("Son güncelleme" to fmt.format(Date(d.lastUpdateTime)))
        add("Kurulum kaynağı" to installerLabel(d.installSource.installing))
        d.installSource.initiating?.let { add("Kurulumu başlatan" to installerLabel(it)) }
        d.installSource.originating?.let { add("Kökeni" to installerLabel(it)) }
        add("Tür" to if (d.isSystem) "Sistem uygulaması" else "Kullanıcı uygulaması")
        add("Android (cihaz)" to "SDK ${d.deviceSdk}")
        add("minSdk / targetSdk" to "${d.minSdk} / ${d.targetSdk}")
        add("Debuggable" to if (d.debuggable) "Evet" else "Hayır")
        add("TEST_BUILD işareti (manifest)" to if (d.testBuildFlag) "Evet — geliştirici belirtmiş" else "Yok")
        add("Test SDK alıcısı" to if (d.testReceiver != null) "Var (debug derleme)" else "Yok")
    }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Button(onClick = onOpen, enabled = canOpen, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
                Text(if (canOpen) "Uygulamayı aç" else "Başlatılabilir ekranı yok")
            }
            if (openFailed) Text("Uygulama açılamadı.", color = MaterialTheme.colorScheme.error)
        }
        items(rows) { (k, v) ->
            Column {
                Text(k, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(v, style = MaterialTheme.typography.bodyLarge)
            }
        }
        item { Text("Uyumluluk", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp)) }
        items(d.compatNotes) { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
        item {
            Text(
                "Yalnızca Android'in herkese açık paket bilgisi gösterilir. Başka uygulamaların özel verilerine, " +
                    "dosyalarına veya APK'larına erişilmez ve bunlar değiştirilmez.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 16.dp),
            )
        }
    }
}
