package com.example.apptest.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Build
import com.example.iaptest.sdk.TestContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Yalnızca Android'in herkese açık PackageManager API'lerini kullanır. Başka uygulamaların
 * özel verilerine/dosyalarına erişmez; APK'ları değiştirmez. Görünürlük, manifestteki <queries>
 * ile sınırlıdır (QUERY_ALL_PACKAGES yok).
 */
class AppRepository(private val context: Context) {
    private val pm: PackageManager = context.packageManager

    suspend fun loadApps(): List<InstalledApp> = withContext(Dispatchers.Default) {
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val sdkPackages = queryReceivers(Intent(TestContract.ACTION)).map { it.activityInfo.packageName }.toSet()

        queryActivities(launcher)
            .map { it.activityInfo.packageName }
            .distinct()
            .filter { it != context.packageName }
            .mapNotNull { pkg ->
                val ai = runCatching { appInfo(pkg) }.getOrNull() ?: return@mapNotNull null
                InstalledApp(
                    packageName = pkg,
                    label = ai.loadLabel(pm).toString(),
                    isSystem = ai.flags and ApplicationInfo.FLAG_SYSTEM != 0,
                    debuggable = ai.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0,
                    testSdk = pkg in sdkPackages,
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    suspend fun loadDetails(pkg: String): AppDetails? = withContext(Dispatchers.Default) {
        runCatching {
            val info = packageInfo(pkg)
            val ai = appInfo(pkg, withMeta = true)
            val minSdk = ai.minSdkVersion
            val target = ai.targetSdkVersion
            AppDetails(
                label = ai.loadLabel(pm).toString(),
                packageName = pkg,
                versionName = info.versionName,
                versionCode = longVersionCode(info),
                firstInstallTime = info.firstInstallTime,
                lastUpdateTime = info.lastUpdateTime,
                minSdk = minSdk,
                targetSdk = target,
                isSystem = ai.flags and ApplicationInfo.FLAG_SYSTEM != 0,
                debuggable = ai.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0,
                testBuildFlag = ai.metaData?.getBoolean(TestContract.META_TEST_BUILD, false) == true,
                installSource = installSource(pkg),
                canOpen = pm.getLaunchIntentForPackage(pkg) != null,
                testReceiver = findReceiver(pkg),
                deviceSdk = Build.VERSION.SDK_INT,
                compatNotes = compatibilityNotes(Build.VERSION.SDK_INT, minSdk, target),
            )
        }.getOrNull()
    }

    fun findReceiver(pkg: String): ComponentName? =
        queryReceivers(Intent(TestContract.ACTION).setPackage(pkg)).firstOrNull()
            ?.activityInfo?.let { ComponentName(it.packageName, it.name) }

    /** Seçilen uygulamayı, Android'in kendi başlatma intent'iyle açar. */
    fun openApp(pkg: String): Boolean {
        val intent = pm.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) ?: return false
        context.startActivity(intent)
        return true
    }

    // --- API seviyesi farklarını gizleyen yardımcılar ---

    @Suppress("DEPRECATION")
    private fun appInfo(pkg: String, withMeta: Boolean = false): ApplicationInfo =
        if (Build.VERSION.SDK_INT >= 33) {
            pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(if (withMeta) PackageManager.GET_META_DATA.toLong() else 0L))
        } else {
            pm.getApplicationInfo(pkg, if (withMeta) PackageManager.GET_META_DATA else 0)
        }

    @Suppress("DEPRECATION")
    private fun packageInfo(pkg: String): PackageInfo =
        if (Build.VERSION.SDK_INT >= 33) pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0L))
        else pm.getPackageInfo(pkg, 0)

    @Suppress("DEPRECATION")
    private fun longVersionCode(info: PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()

    @Suppress("DEPRECATION")
    private fun queryActivities(intent: Intent): List<ResolveInfo> =
        if (Build.VERSION.SDK_INT >= 33) pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        else pm.queryIntentActivities(intent, 0)

    @Suppress("DEPRECATION")
    private fun queryReceivers(intent: Intent): List<ResolveInfo> =
        if (Build.VERSION.SDK_INT >= 33) pm.queryBroadcastReceivers(intent, PackageManager.ResolveInfoFlags.of(0L))
        else pm.queryBroadcastReceivers(intent, 0)

    @Suppress("DEPRECATION")
    private fun installSource(pkg: String): InstallSource = runCatching {
        if (Build.VERSION.SDK_INT >= 30) {
            val s = pm.getInstallSourceInfo(pkg)
            InstallSource(
                s.installingPackageName,
                s.initiatingPackageName,
                if (Build.VERSION.SDK_INT >= 34) s.originatingPackageName else null,
            )
        } else {
            InstallSource(pm.getInstallerPackageName(pkg), null, null)
        }
    }.getOrDefault(InstallSource(null, null, null))
}
