package com.example.apptest

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.apptest.ui.AppDetailScreen
import com.example.apptest.ui.AppListContent
import com.example.apptest.ui.AppListViewModel
import com.example.apptest.ui.AppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val graph = (application as AnalyzerApp).graph
        setContent {
            AppTheme {
                Surface(Modifier.fillMaxSize().safeDrawingPadding()) {
                    val vm: AppListViewModel = viewModel(
                        factory = viewModelFactory { initializer { AppListViewModel(graph) } },
                    )
                    val state by vm.state.collectAsStateWithLifecycle()
                    val selected = state.selected

                    if (selected == null) {
                        AppListContent(
                            apps = state.visible,
                            loading = state.loading,
                            query = state.query,
                            filter = state.filter,
                            onQuery = vm::setQuery,
                            onFilter = vm::setFilter,
                            onSelect = { vm.select(it.packageName) },
                        )
                    } else {
                        BackHandler { vm.select(null) }
                        AppDetailScreen(graph, selected, onBack = { vm.select(null) })
                    }
                }
            }
        }
    }
}
