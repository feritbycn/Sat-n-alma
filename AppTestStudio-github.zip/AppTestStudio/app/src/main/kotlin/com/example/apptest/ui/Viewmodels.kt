package com.example.apptest.ui

import android.content.ComponentName
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.apptest.AppGraph
import com.example.apptest.data.AppDetails
import com.example.apptest.data.AppFilter
import com.example.apptest.data.InstalledApp
import com.example.apptest.data.RemoteReply
import com.example.apptest.data.filterApps
import com.example.iaptest.sdk.SimEvent
import com.example.iaptest.sdk.SimType
import com.example.iaptest.sdk.WalletState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

// ---------- Uygulama listesi ----------

data class AppListState(
    val loading: Boolean = true,
    val all: List<InstalledApp> = emptyList(),
    val query: String = "",
    val filter: AppFilter = AppFilter.ALL,
    val selected: String? = null,
) {
    val visible: List<InstalledApp> get() = filterApps(all, query, filter)
}

class AppListViewModel(private val graph: AppGraph) : ViewModel() {
    private val _state = MutableStateFlow(AppListState())
    val state: StateFlow<AppListState> = _state.asStateFlow()

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val apps = graph.repository.loadApps()
            _state.update { it.copy(loading = false, all = apps) }
        }
    }

    fun setQuery(q: String) = _state.update { it.copy(query = q) }
    fun setFilter(f: AppFilter) = _state.update { it.copy(filter = f) }
    fun select(pkg: String?) = _state.update { it.copy(selected = pkg) }
}

// ---------- Ayrıntı ----------

data class DetailState(val loading: Boolean = true, val details: AppDetails? = null, val openFailed: Boolean = false)

class AppDetailViewModel(private val graph: AppGraph, private val pkg: String) : ViewModel() {
    private val _state = MutableStateFlow(DetailState())
    val state: StateFlow<DetailState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            _state.value = DetailState(loading = false, details = graph.repository.loadDetails(pkg))
        }
    }

    fun open() {
        val ok = runCatching { graph.repository.openApp(pkg) }.getOrDefault(false)
        _state.update { it.copy(openFailed = !ok) }
    }
}

// ---------- Test merkezi ----------

data class TestUiState(
    val appLabel: String,
    val remoteAvailable: Boolean,
    val useLocal: Boolean,
    val wallet: WalletState?,
    val message: Pair<Boolean, String>?,
    val busy: Boolean,
) {
    val targetLabel: String
        get() = if (useLocal) "Yerel simülasyon (bu uygulamanın kendi cüzdanı)" else "$appLabel (test SDK'lı derleme)"
}

class TestCenterViewModel(
    private val graph: AppGraph,
    private val pkg: String,
    private val appLabel: String,
) : ViewModel() {

    private val receiver: ComponentName? = graph.repository.findReceiver(pkg)

    private val useLocal = MutableStateFlow(receiver == null)
    private val remoteWallet = MutableStateFlow<WalletState?>(null)
    private val message = MutableStateFlow<Pair<Boolean, String>?>(null)
    private val busy = MutableStateFlow(false)

    val state: StateFlow<TestUiState> = combine(
        useLocal, remoteWallet, graph.localWallet.state, message, busy,
    ) { local, remote, localWallet, msg, b ->
        TestUiState(
            appLabel = appLabel,
            remoteAvailable = receiver != null,
            useLocal = local,
            wallet = if (local) localWallet else remote,
            message = msg,
            busy = b,
        )
    }.stateIn(
        viewModelScope, SharingStarted.Eagerly,
        TestUiState(appLabel, receiver != null, receiver == null, null, null, false),
    )

    init {
        if (receiver != null) send(SimType.QUERY)
    }

    fun setUseLocal(local: Boolean) {
        if (!local && receiver == null) return
        useLocal.value = local
        message.value = null
        if (!local) send(SimType.QUERY)
    }

    /**
     * Yeni satın alma olayları için benzersiz "SIM-" işlem kimliği üretilir; bekleyen işlemi
     * çözerken mevcut kimlik [txnId] ile verilir. Tokenlar/makbuzlar ÜRETİLMEZ.
     */
    fun send(type: SimType, productId: String? = null, txnId: String? = null, amount: Int = 0) {
        val needsNewId = type in NEW_ID_TYPES
        val event = SimEvent(
            type = type,
            productId = productId,
            txnId = txnId ?: if (needsNewId) "SIM-" + UUID.randomUUID().toString().take(8) else null,
            amount = amount,
        )
        if (useLocal.value) {
            val out = graph.localWallet.apply(event)
            message.value = out.ok to out.message
            return
        }
        val target = receiver ?: return
        viewModelScope.launch {
            busy.value = true
            when (val reply = graph.remote.send(target, event)) {
                is RemoteReply.Answered -> {
                    remoteWallet.value = reply.outcome.state
                    if (type != SimType.QUERY) message.value = reply.outcome.ok to reply.outcome.message
                }
                is RemoteReply.NoAnswer -> message.value = false to reply.reason
            }
            busy.value = false
        }
    }

    private companion object {
        val NEW_ID_TYPES = setOf(
            SimType.PURCHASE_SUCCESS, SimType.PURCHASE_CANCELED, SimType.PURCHASE_FAILED,
            SimType.PURCHASE_PENDING, SimType.SPEND, SimType.RESTORE,
            SimType.CLEAR_LOCAL_ENTITLEMENTS, SimType.RESET_WALLET,
        )
    }
}
