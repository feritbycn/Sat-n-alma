package com.example.apptest.data

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import com.example.iaptest.sdk.SimEvent
import com.example.iaptest.sdk.SimOutcome
import com.example.iaptest.sdk.TestContract
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

sealed interface RemoteReply {
    data class Answered(val outcome: SimOutcome) : RemoteReply
    data class NoAnswer(val reason: String) : RemoteReply
}

/**
 * Seçilen test uygulamasına (kendi oyununuza) simülasyon olayı gönderir.
 * Açık (explicit) bileşene sıralı yayın: alıcı, signature izni olmayan göndericiyi sistem
 * düzeyinde reddeder; release derlemelerinde alıcı hiç bulunmaz.
 */
class RemoteTestClient(private val context: Context) {

    suspend fun send(target: ComponentName, event: SimEvent): RemoteReply {
        val intent = Intent(TestContract.ACTION).setComponent(target).putExtras(event.toBundle())
        val reply = withTimeoutOrNull(TIMEOUT_MS) {
            suspendCancellableCoroutine<Pair<Int, String?>> { cont ->
                val resultReceiver = object : BroadcastReceiver() {
                    override fun onReceive(c: Context, i: Intent) {
                        if (cont.isActive) cont.resume(resultCode to resultData)
                    }
                }
                context.sendOrderedBroadcast(intent, null, resultReceiver, null, TestContract.RESULT_NONE, null, null)
            }
        } ?: return RemoteReply.NoAnswer("Zaman aşımı: uygulama yanıt vermedi.")

        val (code, data) = reply
        if (code == TestContract.RESULT_NONE || data == null) {
            return RemoteReply.NoAnswer(
                "Yanıt yok. Olası nedenler: imza uyuşmuyor (aynı keystore ile imzalayın), " +
                    "uygulama hiç açılmadı/durduruldu veya release derlemesi.",
            )
        }
        val outcome = SimOutcome.fromJson(data) ?: return RemoteReply.NoAnswer("Yanıt çözümlenemedi.")
        return RemoteReply.Answered(outcome)
    }

    private companion object {
        const val TIMEOUT_MS = 5_000L
    }
}
