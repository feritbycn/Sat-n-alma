package com.example.apptest.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Dark = darkColorScheme(
    primary = Color(0xFF4ADE80),
    onPrimary = Color(0xFF05260F),
    secondary = Color(0xFF7DD3FC),
    tertiary = Color(0xFFFBBF24),
    background = Color(0xFF0D1117),
    onBackground = Color(0xFFE6EDF3),
    surface = Color(0xFF161B22),
    onSurface = Color(0xFFE6EDF3),
    surfaceVariant = Color(0xFF21262D),
    onSurfaceVariant = Color(0xFF9DA7B3),
    primaryContainer = Color(0xFF14352A),
    onPrimaryContainer = Color(0xFFBBF7D0),
    tertiaryContainer = Color(0xFF3B2F0B),
    onTertiaryContainer = Color(0xFFFDE68A),
    errorContainer = Color(0xFF4C1D1D),
    onErrorContainer = Color(0xFFFECACA),
    error = Color(0xFFF87171),
)

/** Sade, koyu tema. Sistem temasından bağımsız olarak her zaman koyu. */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Dark, content = content)
}
