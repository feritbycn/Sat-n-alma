package com.example.apptest.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.apptest.AppGraph
import com.example.iaptest.sdk.SimCatalog
import com.example.iaptest.sdk.SimTxn
import com.example.iaptest.sdk.SimType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TestCenterScreen(graph: AppGraph, packageName: String, label: String) {
    val vm: TestCenterViewModel = viewModel(
        key = "test-$packageName",
        factory = viewModelFactory { initializer { TestCenterViewModel(graph, packageName, label) } },
    )
    val state by vm.state.collectAsStateWithLifecycle()
    TestCenterContent(
        state = state,
        onSend = { type, product, txn, amount -> vm.send(type, product, txn, amount) },
        onUseLocal = vm::setUseLocal,
    )
}

private enum class Scenario(val label: String, val type: SimType) {
    SUCCESS("Başarılı", SimType.PURCHASE_SUCCESS),
    CANCELED("İptal", SimType.PURCHASE_CANCELED),
    FAILED("Başarısız", SimType.PURCHASE_FAILED),
    PENDING("Bekleyen", SimType.PURCHASE_PENDING),
}

/** Durumsuz içerik: arayüz testleri doğrudan bunu sınar. */
@Composable
fun TestCenterContent(
    state: TestUiState,
    onSend: (type: SimType, productId: String?, txnId: String?, amount: Int) -> Unit,
    onUseLocal: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    var scenario by remember { mutableStateOf(Scenario.SUCCESS) }
    val wallet = state.wallet

    LazyColumn(
        modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
            ) {
                Text(
                    "SİMÜLASYON: Bu ekrandaki satın almalar, bakiye ve geçmiş gerçek değildir. Google Play ile " +
                        "ilişkisi yoktur; token veya makbuz üretilmez ve gerçek satın alma kayıtlarıyla karıştırılmaz.",
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Hedef: ${state.targetLabel}", style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !state.useLocal,
                        onClick = { onUseLocal(false) },
                        enabled = state.remoteAvailable,
                        label = { Text(if (state.remoteAvailable) state.appLabel else "Uygulama (SDK yok)") },
                    )
                    FilterChip(selected = state.useLocal, onClick = { onUseLocal(true) }, label = { Text("Yerel simülasyon") })
                }
                if (!state.remoteAvailable) {
                    Text(
                        "Bu uygulamada test SDK'sı yok; yerel simülasyon kullanılıyor. Kendi oyununuzu bağlamak için README'ye bakın.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        if (state.busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }

        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Sanal oyun parası bakiyesi (simülasyon)", style = MaterialTheme.typography.labelMedium)
                    Text("${wallet?.balance ?: "—"}", style = MaterialTheme.typography.headlineMedium)
                    Text(
                        "Kalıcı ürünler: " + (wallet?.owned?.takeIf { it.isNotEmpty() }?.joinToString() ?: "yok"),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }
        state.message?.let { (ok, text) ->
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (ok) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(text, Modifier.padding(12.dp)) }
            }
        }

        item { Text("Senaryo", style = MaterialTheme.typography.titleSmall) }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Scenario.entries) { s ->
                    FilterChip(selected = scenario == s, onClick = { scenario = s }, label = { Text(s.label) })
                }
            }
        }
        items(SimCatalog.products, key = { it.id }) { p ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(p.title)
                    Text(
                        if (p.consumable) "tüketilebilir · +${p.coins}" else "kalıcı",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Button(onClick = { onSend(scenario.type, p.id, null, 0) }, enabled = !state.busy) {
                    Text("Simüle et: ${scenario.label}")
                }
            }
        }

        if (!wallet?.pending.isNullOrEmpty()) {
            item { Text("Bekleyen işlemler", style = MaterialTheme.typography.titleSmall) }
            items(wallet!!.pending, key = { it.id }) { p ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${p.productId} · ${p.id}", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { onSend(SimType.RESOLVE_PENDING_SUCCESS, null, p.id, 0) }) { Text("Tamamla") }
                    OutlinedButton(onClick = { onSend(SimType.RESOLVE_PENDING_CANCEL, null, p.id, 0) }) { Text("İptal") }
                }
            }
        }

        item { Text("Geri yükleme ve bakiye", style = MaterialTheme.typography.titleSmall) }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { OutlinedButton(onClick = { onSend(SimType.CLEAR_LOCAL_ENTITLEMENTS, null, null, 0) }) { Text("Yerel yetkileri sil") } }
                item { Button(onClick = { onSend(SimType.RESTORE, null, null, 0) }) { Text("Geri yükle") } }
                item { OutlinedButton(onClick = { onSend(SimType.SPEND, null, null, 50) }) { Text("50 harca") } }
                item { OutlinedButton(onClick = { onSend(SimType.QUERY, null, null, 0) }) { Text("Durumu sorgula") } }
                item { OutlinedButton(onClick = { onSend(SimType.RESET_WALLET, null, null, 0) }) { Text("Sıfırla") } }
            }
        }

        item { Text("İşlem geçmişi (simülasyon)", style = MaterialTheme.typography.titleSmall) }
        if (wallet == null || wallet.history.isEmpty()) item { Text("Henüz işlem yok.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(wallet?.history.orEmpty(), key = { it.id + it.type.name + it.time }) { HistoryRow(it) }
        item { androidx.compose.foundation.layout.Spacer(Modifier.padding(16.dp)) }
    }
}

private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

@Composable
private fun HistoryRow(t: SimTxn) {
    Column {
        Text(
            "SİMÜLASYON · ${timeFmt.format(Date(t.time))} · ${t.id}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.tertiary,
        )
        Text("${t.type.label}${t.productId?.let { " · $it" } ?: ""} → ${t.status} (bakiye ${t.balanceAfter})")
    }
}
