package com.example.apptest.data

/** Saf (Android'siz) mantık: JVM birim testlerinde doğrulanır. */

fun filterApps(apps: List<InstalledApp>, query: String, filter: AppFilter): List<InstalledApp> {
    val q = query.trim().lowercase()
    return apps.filter { app ->
        val byFilter = when (filter) {
            AppFilter.ALL -> true
            AppFilter.USER -> !app.isSystem
            AppFilter.SYSTEM -> app.isSystem
            AppFilter.DEBUGGABLE -> app.debuggable
            AppFilter.TEST_SDK -> app.testSdk
        }
        byFilter && (q.isEmpty() || app.label.lowercase().contains(q) || app.packageName.lowercase().contains(q))
    }
}

fun installerLabel(pkg: String?): String = when (pkg) {
    null -> "Bilinmiyor (adb, sistem imajı veya bilgi erişilemiyor)"
    "com.android.vending" -> "Google Play Store"
    "com.sec.android.app.samsungapps" -> "Samsung Galaxy Store"
    "com.amazon.venezia" -> "Amazon Appstore"
    "com.huawei.appmarket" -> "Huawei AppGallery"
    "com.android.packageinstaller", "com.google.android.packageinstaller" ->
        "Paket yükleyici (APK dosyasından yan yükleme)"
    else -> pkg
}

fun compatibilityNotes(deviceSdk: Int, minSdk: Int, targetSdk: Int): List<String> = buildList {
    if (minSdk > deviceSdk) add("minSdk ($minSdk) bu cihazın SDK'sından ($deviceSdk) yüksek: bu cihazda çalışmaz.")
    else add("minSdk ($minSdk) bu cihazla uyumlu (cihaz SDK $deviceSdk).")

    when {
        targetSdk < 23 && deviceSdk >= 34 ->
            add("Hedef SDK $targetSdk: Android 14+ cihazlar hedef SDK'sı 23'ün altındaki uygulamaların kurulumunu engeller.")
        deviceSdk - targetSdk >= 3 ->
            add("Hedef SDK $targetSdk, cihazın ${deviceSdk - targetSdk} sürüm gerisinde: uyumluluk davranışları devreye girebilir.")
        targetSdk > deviceSdk ->
            add("Hedef SDK $targetSdk, cihaz SDK'sından yeni; yeni API'ler eksik olabilir.")
        else -> add("Hedef SDK $targetSdk cihaza yakın; ek uyumluluk uyarısı yok.")
    }
}
