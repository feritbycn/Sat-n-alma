package com.example.apptest.data

import android.content.ComponentName

data class InstalledApp(
    val packageName: String,
    val label: String,
    val isSystem: Boolean,
    val debuggable: Boolean,
    /** Uygulamada test SDK'sı alıcısı var mı (yalnızca geliştiricinin debug derlemelerinde olur). */
    val testSdk: Boolean,
)

enum class AppFilter(val label: String) {
    ALL("Tümü"),
    USER("Kullanıcı"),
    SYSTEM("Sistem"),
    DEBUGGABLE("Debuggable"),
    TEST_SDK("Test SDK'lı"),
}

data class InstallSource(val installing: String?, val initiating: String?, val originating: String?)

data class AppDetails(
    val label: String,
    val packageName: String,
    val versionName: String?,
    val versionCode: Long,
    val firstInstallTime: Long,
    val lastUpdateTime: Long,
    val minSdk: Int,
    val targetSdk: Int,
    val isSystem: Boolean,
    val debuggable: Boolean,
    /** Geliştiricinin manifestte açıkça koyduğu TEST_BUILD işareti. */
    val testBuildFlag: Boolean,
    val installSource: InstallSource,
    val canOpen: Boolean,
    /** Test SDK'sı alıcısı varsa bileşen adı. */
    val testReceiver: ComponentName?,
    val deviceSdk: Int,
    val compatNotes: List<String>,
)
