package com.example.apptest

import android.app.Application
import com.example.apptest.data.AppRepository
import com.example.apptest.data.RemoteTestClient
import com.example.iaptest.sdk.PrefsStore
import com.example.iaptest.sdk.SimWallet

class AppGraph(app: Application) {
    val repository = AppRepository(app)
    val remote = RemoteTestClient(app)

    /** "Yerel simülasyon" hedefi: hiçbir uygulamaya bağlı olmayan, ayrı dosyada tutulan cüzdan. */
    val localWallet = SimWallet(PrefsStore(app, "analyzer_local_sim_wallet"))
}

class AnalyzerApp : Application() {
    lateinit var graph: AppGraph
        private set

    override fun onCreate() {
        super.onCreate()
        graph = AppGraph(this)
    }
}
