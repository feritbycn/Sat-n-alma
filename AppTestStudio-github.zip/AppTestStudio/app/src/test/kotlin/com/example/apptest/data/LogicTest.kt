package com.example.apptest.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LogicTest {
    private val apps = listOf(
        InstalledApp("com.android.calculator2", "Calculator", isSystem = true, debuggable = false, testSdk = false),
        InstalledApp("com.android.camera", "Camera", isSystem = true, debuggable = false, testSdk = false),
        InstalledApp("com.example.game", "Benim Oyunum", isSystem = false, debuggable = true, testSdk = true),
        InstalledApp("org.notes", "Notlar", isSystem = false, debuggable = false, testSdk = false),
    )

    @Test fun search_matchesLabelOrPackage_caseInsensitive() {
        assertEquals(listOf("Calculator"), filterApps(apps, "CALC", AppFilter.ALL).map { it.label })
        assertEquals(listOf("Benim Oyunum"), filterApps(apps, "example.game", AppFilter.ALL).map { it.label })
        assertEquals(4, filterApps(apps, "  ", AppFilter.ALL).size)
    }

    @Test fun filters_work() {
        assertEquals(2, filterApps(apps, "", AppFilter.SYSTEM).size)
        assertEquals(2, filterApps(apps, "", AppFilter.USER).size)
        assertEquals(listOf("Benim Oyunum"), filterApps(apps, "", AppFilter.DEBUGGABLE).map { it.label })
        assertEquals(listOf("Benim Oyunum"), filterApps(apps, "", AppFilter.TEST_SDK).map { it.label })
    }

    @Test fun searchAndFilter_combine() {
        assertTrue(filterApps(apps, "cam", AppFilter.USER).isEmpty())
    }

    @Test fun installerLabels() {
        assertEquals("Google Play Store", installerLabel("com.android.vending"))
        assertTrue(installerLabel("com.google.android.packageinstaller").contains("yan yükleme"))
        assertTrue(installerLabel(null).startsWith("Bilinmiyor"))
        assertEquals("com.foo.store", installerLabel("com.foo.store"))
    }

    @Test fun compat_minSdkTooHigh() {
        assertTrue(compatibilityNotes(deviceSdk = 30, minSdk = 33, targetSdk = 34).first().contains("çalışmaz"))
    }

    @Test fun compat_oldTargetBlockedOnAndroid14() {
        assertTrue(compatibilityNotes(deviceSdk = 35, minSdk = 21, targetSdk = 22).any { it.contains("engeller") })
    }

    @Test fun compat_fineCase() {
        val notes = compatibilityNotes(deviceSdk = 35, minSdk = 24, targetSdk = 35)
        assertTrue(notes.any { it.contains("uyumlu") })
        assertTrue(notes.any { it.contains("ek uyumluluk uyarısı yok") })
    }
}
