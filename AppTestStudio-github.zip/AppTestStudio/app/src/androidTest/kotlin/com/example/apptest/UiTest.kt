package com.example.apptest

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.apptest.data.AppFilter
import com.example.apptest.data.InstalledApp
import com.example.apptest.data.filterApps
import com.example.apptest.ui.AppListContent
import com.example.apptest.ui.AppTheme
import com.example.apptest.ui.TestCenterContent
import com.example.apptest.ui.TestUiState
import com.example.iaptest.sdk.SimType
import com.example.iaptest.sdk.WalletState
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class UiTest {
    @get:Rule val rule = createComposeRule()

    private val sample = listOf(
        InstalledApp("pkg.calc", "Calculator", isSystem = true, debuggable = false, testSdk = false),
        InstalledApp("pkg.camera", "Camera", isSystem = true, debuggable = false, testSdk = false),
    )

    @Test
    fun search_filtersTheList() {
        rule.setContent {
            AppTheme {
                var q by remember { mutableStateOf("") }
                var f by remember { mutableStateOf(AppFilter.ALL) }
                AppListContent(filterApps(sample, q, f), false, q, f, { q = it }, { f = it }, {})
            }
        }
        rule.onNodeWithText("Calculator").assertIsDisplayed()
        rule.onNodeWithText("Camera").assertIsDisplayed()

        rule.onNodeWithTag("search").performTextInput("calc")
        rule.onNodeWithText("Calculator").assertIsDisplayed()
        rule.onNodeWithText("Camera").assertDoesNotExist()
    }

    @Test
    fun testCenter_showsSimulationBanner_andSendsSelectedScenario() {
        var sent: Pair<SimType, String?>? = null
        rule.setContent {
            AppTheme {
                TestCenterContent(
                    state = TestUiState("Oyunum", false, true, WalletState(balance = 120), null, false),
                    onSend = { type, product, _, _ -> sent = type to product },
                    onUseLocal = {},
                )
            }
        }
        rule.onNodeWithText("SİMÜLASYON:", substring = true).assertIsDisplayed()
        rule.onNodeWithText("120").assertIsDisplayed()

        rule.onNodeWithText("İptal").performClick() // senaryo çipi
        rule.onNodeWithText("Simüle et: İptal", useUnmergedTree = true).performClick()
        assertEquals(SimType.PURCHASE_CANCELED, sent?.first)
    }
}
