package com.example.iaptest.sdk

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SimWalletTest {
    private var now = 1_000L
    private fun wallet(store: KeyValueStore = InMemoryStore()) = SimWallet(store) { now++ }

    private fun SimWallet.buy(id: String, txn: String) = apply(SimEvent(SimType.PURCHASE_SUCCESS, id, txn))

    @Test
    fun success_addsCoins_andRecordsHistory() {
        val w = wallet()
        val r = w.buy("coins_100", "SIM-1")
        assertTrue(r.ok)
        assertEquals(100, w.state.value.balance)
        assertEquals("BAŞARILI", w.state.value.history.first().status)
    }

    @Test
    fun duplicateEvent_isIgnored() {
        val w = wallet()
        w.buy("coins_100", "SIM-1")
        val again = w.buy("coins_100", "SIM-1")
        assertTrue(again.ok)
        assertEquals(100, w.state.value.balance)
        assertEquals(1, w.state.value.history.size)
    }

    @Test
    fun canceledAndFailed_doNotChangeBalance() {
        val w = wallet()
        w.apply(SimEvent(SimType.PURCHASE_CANCELED, "coins_100", "SIM-a"))
        w.apply(SimEvent(SimType.PURCHASE_FAILED, "coins_100", "SIM-b"))
        assertEquals(0, w.state.value.balance)
        assertEquals(listOf("BAŞARISIZ", "İPTAL"), w.state.value.history.map { it.status })
    }

    @Test
    fun pending_grantsNothing_untilResolved() {
        val w = wallet()
        w.apply(SimEvent(SimType.PURCHASE_PENDING, "coins_500", "SIM-p"))
        assertEquals(0, w.state.value.balance)
        assertEquals(1, w.state.value.pending.size)

        w.apply(SimEvent(SimType.RESOLVE_PENDING_SUCCESS, txnId = "SIM-p"))
        assertEquals(500, w.state.value.balance)
        assertTrue(w.state.value.pending.isEmpty())
    }

    @Test
    fun pending_canBeCanceled() {
        val w = wallet()
        w.apply(SimEvent(SimType.PURCHASE_PENDING, "coins_500", "SIM-p"))
        w.apply(SimEvent(SimType.RESOLVE_PENDING_CANCEL, txnId = "SIM-p"))
        assertEquals(0, w.state.value.balance)
        assertTrue(w.state.value.pending.isEmpty())
    }

    @Test
    fun resolvingUnknownPending_isRejected() {
        val r = wallet().apply(SimEvent(SimType.RESOLVE_PENDING_SUCCESS, txnId = "SIM-yok"))
        assertFalse(r.ok)
    }

    @Test
    fun nonConsumable_cannotBeBoughtTwice() {
        val w = wallet()
        assertTrue(w.buy("remove_ads", "SIM-1").ok)
        assertFalse(w.buy("remove_ads", "SIM-2").ok)
        assertEquals(setOf("remove_ads"), w.state.value.owned)
    }

    @Test
    fun restore_returnsNonConsumables_withoutChangingBalance() {
        val w = wallet()
        w.buy("remove_ads", "SIM-1")
        w.buy("coins_100", "SIM-2")
        w.apply(SimEvent(SimType.CLEAR_LOCAL_ENTITLEMENTS))
        assertTrue(w.state.value.owned.isEmpty())

        val r = w.apply(SimEvent(SimType.RESTORE))
        assertTrue(r.ok)
        assertEquals(setOf("remove_ads"), w.state.value.owned)
        assertEquals(100, w.state.value.balance)
    }

    @Test
    fun spend_reducesBalance_andRejectsOverspend() {
        val w = wallet()
        w.buy("coins_100", "SIM-1")
        assertTrue(w.apply(SimEvent(SimType.SPEND, amount = 40)).ok)
        assertEquals(60, w.state.value.balance)
        assertFalse(w.apply(SimEvent(SimType.SPEND, amount = 61)).ok)
        assertEquals(60, w.state.value.balance)
    }

    @Test
    fun balanceAndHistory_surviveReload() {
        val store = InMemoryStore()
        val a = wallet(store)
        a.buy("coins_500", "SIM-1")
        a.buy("remove_ads", "SIM-2")
        a.apply(SimEvent(SimType.SPEND, amount = 200))

        val b = wallet(store) // uygulama yeniden başlatıldı
        assertEquals(300, b.state.value.balance)
        assertEquals(setOf("remove_ads"), b.state.value.owned)
        assertEquals(3, b.state.value.history.size)
    }

    @Test
    fun unknownProduct_isRejected() {
        assertFalse(wallet().buy("nope", "SIM-1").ok)
    }

    @Test
    fun outcomeJson_roundTrips() {
        val w = wallet()
        w.buy("coins_100", "SIM-1")
        val out = w.apply(SimEvent(SimType.PURCHASE_PENDING, "coins_500", "SIM-2"))
        val back = SimOutcome.fromJson(out.toJson().toString())
        assertEquals(out, back)
    }

    @Test
    fun setBalance_setsAbsoluteValue_andSpendWorks() {
        val w = wallet()
        assertTrue(w.apply(SimEvent(SimType.SET_BALANCE, null, "SIM-s", 1000)).ok)
        assertEquals(1000, w.state.value.balance)
        w.apply(SimEvent(SimType.SPEND, null, "SIM-p", 250))
        assertEquals(750, w.state.value.balance)
    }

    @Test
    fun thousandCoinProduct_addsThousand() {
        val w = wallet()
        assertTrue(w.buy("coins_1000", "SIM-k").ok)
        assertEquals(1000, w.state.value.balance)
    }

    @Test
    fun starterPack_isPermanent_andGrantsCoinsOnce() {
        val w = wallet()
        assertTrue(w.buy("starter_pack", "SIM-a").ok)
        assertEquals(500, w.state.value.balance)
        assertFalse(w.buy("starter_pack", "SIM-b").ok)
        assertEquals(500, w.state.value.balance)
    }
}
