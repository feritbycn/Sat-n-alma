package com.example.iaptest.sdk

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

interface KeyValueStore {
    fun get(key: String): String?
    fun put(key: String, value: String)
}

class InMemoryStore : KeyValueStore {
    private val map = HashMap<String, String>()
    override fun get(key: String) = map[key]
    override fun put(key: String, value: String) { map[key] = value }
}

class PrefsStore(context: Context, name: String) : KeyValueStore {
    private val prefs = context.applicationContext.getSharedPreferences(name, Context.MODE_PRIVATE)
    override fun get(key: String): String? = prefs.getString(key, null)
    override fun put(key: String, value: String) = prefs.edit().putString(key, value).apply()
}

/**
 * Simüle edilmiş oyun parası cüzdanı. Tüm kurallar tek yerde, saf bir indirgeyicide (reduce).
 * Gerçek satın alma, token veya Google Play ile hiçbir bağı yoktur; kayıtlar kendi
 * depolama dosyasında tutulur ve her yerde "SİMÜLASYON" olarak etiketlenmelidir.
 */
class SimWallet(
    private val store: KeyValueStore,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private val _state = MutableStateFlow(load())
    val state: StateFlow<WalletState> = _state.asStateFlow()

    @Synchronized
    fun apply(event: SimEvent): SimOutcome {
        val before = _state.value
        val r = reduce(before, event, clock())
        if (r.state != before) {
            _state.value = r.state
            store.put(KEY, r.state.toJson().toString())
        }
        return SimOutcome(r.ok, r.message, r.state)
    }

    private fun load(): WalletState =
        store.get(KEY)?.let { runCatching { WalletState.fromJson(JSONObject(it)) }.getOrNull() } ?: WalletState()

    private data class Reduction(val state: WalletState, val ok: Boolean, val message: String)

    private fun reject(s: WalletState, msg: String) = Reduction(s, false, msg)

    private fun record(s: WalletState, t: SimTxn) = s.copy(history = (listOf(t) + s.history).take(MAX_HISTORY))

    private fun grant(s: WalletState, p: SimProduct, txn: String, type: SimType, now: Long): Reduction {
        if (!p.consumable && p.id in s.owned) return reject(s, "${p.title}: zaten sahipsiniz")
        val balance = s.balance + p.coins
        val next = s.copy(
            balance = balance,
            owned = if (p.consumable) s.owned else s.owned + p.id,
            restorable = if (p.consumable) s.restorable else s.restorable + p.id,
        )
        return Reduction(
            record(next, SimTxn(txn, p.id, type, "BAŞARILI", now, balance)),
            true,
            "${p.title}: başarılı (simülasyon)" + if (p.coins > 0) ", +${p.coins} oyun parası" else "",
        )
    }

    private fun reduce(s: WalletState, e: SimEvent, now: Long): Reduction {
        val txn = e.txnId ?: ("SIM-" + now.toString(36))
        // Yinelenen olay koruması: aynı işlem kimliği + aynı olay türü iki kez uygulanmaz.
        if (e.txnId != null && e.type != SimType.QUERY && s.history.any { it.id == e.txnId && it.type == e.type }) {
            return Reduction(s, true, "Yinelenen olay yok sayıldı (${e.txnId})")
        }
        return when (e.type) {
            SimType.QUERY -> Reduction(s, true, "Durum okundu")

            SimType.PURCHASE_SUCCESS -> {
                val p = SimCatalog.find(e.productId) ?: return reject(s, "Bilinmeyen ürün: ${e.productId}")
                grant(s, p, txn, e.type, now)
            }

            SimType.PURCHASE_CANCELED, SimType.PURCHASE_FAILED -> {
                val p = SimCatalog.find(e.productId) ?: return reject(s, "Bilinmeyen ürün: ${e.productId}")
                val canceled = e.type == SimType.PURCHASE_CANCELED
                Reduction(
                    record(s, SimTxn(txn, p.id, e.type, if (canceled) "İPTAL" else "BAŞARISIZ", now, s.balance)),
                    true,
                    "${p.title}: ${if (canceled) "iptal edildi" else "başarısız"} (simülasyon); bakiye değişmedi",
                )
            }

            SimType.PURCHASE_PENDING -> {
                val p = SimCatalog.find(e.productId) ?: return reject(s, "Bilinmeyen ürün: ${e.productId}")
                val next = s.copy(pending = s.pending + PendingTxn(txn, p.id, now))
                Reduction(
                    record(next, SimTxn(txn, p.id, e.type, "BEKLEMEDE", now, s.balance)),
                    true,
                    "${p.title}: beklemede; tamamlanana kadar yetki/bakiye verilmez",
                )
            }

            SimType.RESOLVE_PENDING_SUCCESS -> {
                val pend = s.pending.firstOrNull { it.id == e.txnId } ?: return reject(s, "Bekleyen işlem bulunamadı")
                val p = SimCatalog.find(pend.productId) ?: return reject(s, "Bilinmeyen ürün")
                grant(s.copy(pending = s.pending - pend), p, pend.id, e.type, now)
            }

            SimType.RESOLVE_PENDING_CANCEL -> {
                val pend = s.pending.firstOrNull { it.id == e.txnId } ?: return reject(s, "Bekleyen işlem bulunamadı")
                val next = s.copy(pending = s.pending - pend)
                Reduction(
                    record(next, SimTxn(pend.id, pend.productId, e.type, "İPTAL (bekleyen)", now, s.balance)),
                    true,
                    "Bekleyen işlem iptal edildi; bakiye değişmedi",
                )
            }

            SimType.CLEAR_LOCAL_ENTITLEMENTS -> Reduction(
                record(s.copy(owned = emptySet()), SimTxn(txn, null, e.type, "YEREL YETKİ SİLİNDİ", now, s.balance)),
                true,
                "Yerel kalıcı yetkiler silindi (veri kaybı simülasyonu); bakiye korunur",
            )

            SimType.RESTORE -> {
                val restored = s.restorable - s.owned
                val next = s.copy(owned = s.owned + s.restorable)
                Reduction(
                    record(next, SimTxn(txn, null, e.type, "GERİ YÜKLENDİ", now, s.balance)),
                    true,
                    "${restored.size} kalıcı ürün geri yüklendi; oyun parası bakiyesi DEĞİŞMEZ",
                )
            }

            SimType.SPEND -> {
                if (e.amount <= 0) return reject(s, "Geçersiz tutar")
                if (s.balance < e.amount) return reject(s, "Yetersiz bakiye (${s.balance} < ${e.amount})")
                val balance = s.balance - e.amount
                Reduction(
                    record(s.copy(balance = balance), SimTxn(txn, null, e.type, "HARCANDI -${e.amount}", now, balance)),
                    true,
                    "${e.amount} oyun parası harcandı; kalan $balance",
                )
            }

            SimType.RESET_WALLET -> Reduction(
                WalletState(history = listOf(SimTxn(txn, null, e.type, "SIFIRLANDI", now, 0))),
                true,
                "Cüzdan sıfırlandı",
            )
        }
    }

    companion object {
        private const val KEY = "wallet_state"
        private const val MAX_HISTORY = 100

        @Volatile
        private var shared: SimWallet? = null

        /** Oyun tarafında tek örnek: alıcı ve arayüz aynı bellek içi durumu paylaşır. */
        fun shared(context: Context): SimWallet =
            shared ?: synchronized(this) {
                shared ?: SimWallet(PrefsStore(context, "sim_wallet")).also { shared = it }
            }
    }
}
