package com.example.iaptest.sdk

import android.os.Bundle
import org.json.JSONArray
import org.json.JSONObject

/** Test olaylarının taşıma sözleşmesi (analiz uygulaması ↔ test oyunu). */
object TestContract {
    const val ACTION = "com.example.iaptest.action.TEST_EVENT"
    const val PERMISSION = "com.example.iaptest.permission.SEND_TEST_EVENT"

    /** Geliştiricinin debug manifestinde açıkça koyduğu işaret. */
    const val META_TEST_BUILD = "com.example.iaptest.TEST_BUILD"

    const val EXTRA_TYPE = "type"
    const val EXTRA_PRODUCT = "product_id"
    const val EXTRA_TXN = "txn_id"
    const val EXTRA_AMOUNT = "amount"

    /** Sıralı yayında yanıt kodları. 0 = hiç yanıt gelmedi. */
    const val RESULT_NONE = 0
    const val RESULT_OK = 1
    const val RESULT_REJECTED = 2
}

enum class SimType(val label: String) {
    QUERY("Durum sorgula"),
    PURCHASE_SUCCESS("Başarılı satın alma"),
    PURCHASE_CANCELED("İptal edilen satın alma"),
    PURCHASE_FAILED("Başarısız satın alma"),
    PURCHASE_PENDING("Bekleyen satın alma"),
    RESOLVE_PENDING_SUCCESS("Bekleyen → başarılı"),
    RESOLVE_PENDING_CANCEL("Bekleyen → iptal"),
    RESTORE("Satın almaları geri yükle"),
    CLEAR_LOCAL_ENTITLEMENTS("Yerel yetkileri sil (veri kaybı)"),
    SPEND("Oyun parası harca"),
    RESET_WALLET("Cüzdanı sıfırla"),
    /** Yalnızca Test Lab köprüsü: bakiyeyi mutlak değere ayarlar (simülasyon). */
    SET_BALANCE("Bakiyeyi ayarla (Test Lab)"),
}

/**
 * Bir simülasyon olayı. Bilerek token/makbuz alanı YOKTUR; txnId yalnızca "SIM-..." önekli
 * bir test kimliğidir ve Google Play ile hiçbir ilişkisi yoktur.
 */
data class SimEvent(
    val type: SimType,
    val productId: String? = null,
    val txnId: String? = null,
    val amount: Int = 0,
) {
    fun toBundle(): Bundle = Bundle().apply {
        putString(TestContract.EXTRA_TYPE, type.name)
        productId?.let { putString(TestContract.EXTRA_PRODUCT, it) }
        txnId?.let { putString(TestContract.EXTRA_TXN, it) }
        putInt(TestContract.EXTRA_AMOUNT, amount)
    }

    companion object {
        fun fromBundle(b: Bundle?): SimEvent? {
            if (b == null) return null
            val name = b.getString(TestContract.EXTRA_TYPE) ?: return null
            val type = SimType.entries.firstOrNull { it.name == name } ?: return null
            return SimEvent(
                type = type,
                productId = b.getString(TestContract.EXTRA_PRODUCT),
                txnId = b.getString(TestContract.EXTRA_TXN),
                amount = b.getInt(TestContract.EXTRA_AMOUNT, 0),
            )
        }
    }
}

data class SimProduct(val id: String, val title: String, val coins: Int, val consumable: Boolean)

object SimCatalog {
    val products = listOf(
        SimProduct("coins_100", "100 Oyun Parası", 100, consumable = true),
        SimProduct("coins_500", "500 Oyun Parası", 500, consumable = true),
        SimProduct("coins_1000", "1.000 Oyun Parası", 1000, consumable = true),
        SimProduct("coins_5000", "5.000 Oyun Parası", 5000, consumable = true),
        SimProduct("starter_pack", "Başlangıç Paketi", 500, consumable = false),
        SimProduct("special_pack", "Özel Test Paketi", 0, consumable = false),
        SimProduct("remove_ads", "Reklamları Kaldır", 0, consumable = false),
    )

    fun find(id: String?): SimProduct? = products.firstOrNull { it.id == id }
}

data class PendingTxn(val id: String, val productId: String, val time: Long)

data class SimTxn(
    val id: String,
    val productId: String?,
    val type: SimType,
    val status: String,
    val time: Long,
    val balanceAfter: Int,
)

/** Simüle edilmiş cüzdan durumu. Gerçek Google Play kaydı DEĞİLDİR. */
data class WalletState(
    val balance: Int = 0,
    /** Cihazda yerel olarak tanınan kalıcı ürünler. */
    val owned: Set<String> = emptySet(),
    /** "Sunucu tarafında" saklı kabul edilen kalıcı ürünler; geri yüklemede kullanılır. */
    val restorable: Set<String> = emptySet(),
    val pending: List<PendingTxn> = emptyList(),
    /** En yeni başta. */
    val history: List<SimTxn> = emptyList(),
) {
    fun toJson(): JSONObject = JSONObject()
        .put("balance", balance)
        .put("owned", JSONArray(owned.toList()))
        .put("restorable", JSONArray(restorable.toList()))
        .put(
            "pending",
            JSONArray(pending.map { JSONObject().put("id", it.id).put("product", it.productId).put("time", it.time) }),
        )
        .put(
            "history",
            JSONArray(
                history.map {
                    JSONObject()
                        .put("id", it.id).put("product", it.productId ?: JSONObject.NULL)
                        .put("type", it.type.name).put("status", it.status)
                        .put("time", it.time).put("balance", it.balanceAfter)
                },
            ),
        )

    companion object {
        fun fromJson(o: JSONObject): WalletState {
            fun strings(a: JSONArray?): Set<String> = (0 until (a?.length() ?: 0)).map { a!!.getString(it) }.toSet()
            val pendingArr = o.optJSONArray("pending")
            val historyArr = o.optJSONArray("history")
            return WalletState(
                balance = o.optInt("balance", 0),
                owned = strings(o.optJSONArray("owned")),
                restorable = strings(o.optJSONArray("restorable")),
                pending = (0 until (pendingArr?.length() ?: 0)).map {
                    val p = pendingArr!!.getJSONObject(it)
                    PendingTxn(p.getString("id"), p.getString("product"), p.optLong("time"))
                },
                history = (0 until (historyArr?.length() ?: 0)).mapNotNull {
                    val h = historyArr!!.getJSONObject(it)
                    val type = SimType.entries.firstOrNull { t -> t.name == h.optString("type") } ?: return@mapNotNull null
                    SimTxn(
                        id = h.getString("id"),
                        productId = if (h.isNull("product")) null else h.getString("product"),
                        type = type,
                        status = h.optString("status"),
                        time = h.optLong("time"),
                        balanceAfter = h.optInt("balance"),
                    )
                },
            )
        }
    }
}

data class SimOutcome(val ok: Boolean, val message: String, val state: WalletState) {
    fun toJson(): JSONObject = JSONObject().put("ok", ok).put("message", message).put("state", state.toJson())

    companion object {
        fun fromJson(s: String): SimOutcome? = runCatching {
            val o = JSONObject(s)
            SimOutcome(o.getBoolean("ok"), o.getString("message"), WalletState.fromJson(o.getJSONObject("state")))
        }.getOrNull()
    }
}
