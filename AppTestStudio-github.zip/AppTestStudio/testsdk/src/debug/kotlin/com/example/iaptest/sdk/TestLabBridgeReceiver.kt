package com.example.iaptest.sdk

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo

/**
 * SADECE debug: "Test Lab" uygulamasından gelen olayları SimWallet'a (simülasyon) işler.
 * Korumalar: (1) signature izni: yalnızca Test Lab ile aynı anahtarla imzalı uygulama gönderebilir,
 * (2) debuggable denetimi, (3) yalnızca SimWallet'a yazar; Google Play'e dokunmaz.
 * Onay (Activity.RESULT_OK) yalnızca olay gerçekten işlendiyse verilir.
 */
class TestLabBridgeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION) return
        if (intent.getStringExtra("source") != "TestLab-simulation") return
        val debuggable = context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0
        if (!debuggable) { reply(false, "Debuggable olmayan derleme: olay reddedildi"); return }

        val wallet = SimWallet.shared(context)
        val stamp = intent.getLongExtra("sentAt", System.currentTimeMillis())
        when (intent.getStringExtra("type")) {
            "PURCHASE" -> handlePurchase(wallet, intent, stamp)
            "BALANCE" -> handleBalance(wallet, intent, stamp)
            else -> reply(false, "Bilinmeyen olay türü")
        }
    }

    private fun handlePurchase(wallet: SimWallet, intent: Intent, stamp: Long) {
        val product = mapProduct(intent.getStringExtra("productId"))
        val scenario = intent.getStringExtra("scenario")
        val txn = "TL-$stamp"
        val event: SimEvent = when (scenario) {
            "SUCCESS" -> SimEvent(SimType.PURCHASE_SUCCESS, product ?: return reply(false, "Bilinmeyen ürün"), txn)
            "CANCEL" -> SimEvent(SimType.PURCHASE_CANCELED, product ?: return reply(false, "Bilinmeyen ürün"), txn)
            "ERROR" -> SimEvent(SimType.PURCHASE_FAILED, product ?: return reply(false, "Bilinmeyen ürün"), txn)
            "PENDING" -> SimEvent(SimType.PURCHASE_PENDING, product ?: return reply(false, "Bilinmeyen ürün"), txn)
            "RESTORE" -> SimEvent(SimType.RESTORE, null, txn)
            "OWNED" -> {
                val p = SimCatalog.find(product) ?: return reply(false, "Bilinmeyen ürün")
                val s = wallet.state.value
                when {
                    !p.consumable && p.id in s.owned -> return reply(true, "${p.title}: zaten sahipsiniz; tekrar işlenmedi")
                    !p.consumable && p.id in s.restorable -> SimEvent(SimType.RESTORE, null, txn)
                    else -> return reply(false, "Sahiplik kaydı yok; ödül verilmedi")
                }
            }
            else -> return reply(false, "Bilinmeyen senaryo: $scenario")
        }
        val out = wallet.apply(event)
        reply(out.ok, out.message + " | Bakiye: ${out.state.balance}, ürünler: ${out.state.owned.joinToString().ifEmpty { "yok" }}")
    }

    private fun handleBalance(wallet: SimWallet, intent: Intent, stamp: Long) {
        val balance = intent.getIntExtra("balance", -1)
        if (balance < 0) return reply(false, "Geçersiz bakiye")
        val first = wallet.apply(SimEvent(SimType.SET_BALANCE, null, "TL-BAL-$stamp", balance))
        if (!first.ok) return reply(false, first.message)
        // Paketler: bilinen kalıcı ürünler yerel yetki olarak işlenir; zaten sahipse atlanır.
        val packs = intent.getStringArrayListExtra("packs").orEmpty()
        var granted = 0
        packs.mapNotNull { mapProduct(it) }.filter { SimCatalog.find(it)?.consumable == false }.forEach { id ->
            if (id !in wallet.state.value.owned) {
                // Paket altını bakiyeyi bozmasın: önce işle, sonra bakiyeyi yeniden ayarla.
                wallet.apply(SimEvent(SimType.PURCHASE_SUCCESS, id, "TL-PACK-$id-$stamp")).takeIf { it.ok }?.let { granted++ }
            }
        }
        if (granted > 0) wallet.apply(SimEvent(SimType.SET_BALANCE, null, "TL-BAL2-$stamp", balance))
        reply(true, "Bakiye ${wallet.state.value.balance}, paket: ${wallet.state.value.owned.joinToString().ifEmpty { "yok" }}")
    }

    /** Test Lab ürün kimliklerini oyunun katalog kimliklerine çevirir; oyunun kendi kimlikleri de kabul edilir. */
    private fun mapProduct(id: String?): String? {
        val mapped = when (id) {
            "gold_100" -> "coins_100"
            "gold_1000" -> "coins_1000"
            "gold_5000" -> "coins_5000"
            "special_test_pack" -> "special_pack"
            else -> id
        }
        return SimCatalog.find(mapped)?.id
    }

    private fun reply(ok: Boolean, message: String) {
        if (isOrderedBroadcast) setResult(if (ok) Activity.RESULT_OK else Activity.RESULT_CANCELED, message, null)
    }

    companion object {
        const val ACTION = "com.example.testlab.action.TEST_EVENT"
    }
}
