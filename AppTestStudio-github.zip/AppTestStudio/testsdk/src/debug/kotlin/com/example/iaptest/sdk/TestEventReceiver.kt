package com.example.iaptest.sdk

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo

/**
 * SADECE debug varyantında derlenir ve bildirilir (src/debug). Release'te sınıf da yoktur.
 *
 * Savunma katmanları:
 *  1. Manifest: signature düzeyinde izin → yalnızca aynı anahtarla imzalı uygulama gönderebilir.
 *  2. Çalışma zamanı: uygulama debuggable değilse olay reddedilir.
 *  3. Olay yalnızca SimWallet'a (simülasyon) işler; Google Play/Billing'e dokunmaz.
 */
class TestEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TestContract.ACTION) return
        val wallet = SimWallet.shared(context)

        val debuggable = context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0
        val event = SimEvent.fromBundle(intent.extras)
        val outcome = when {
            !debuggable -> SimOutcome(false, "Debuggable olmayan derleme: test olayı reddedildi", wallet.state.value)
            event == null -> SimOutcome(false, "Geçersiz test olayı", wallet.state.value)
            else -> wallet.apply(event)
        }
        if (isOrderedBroadcast) {
            val code = if (outcome.ok) TestContract.RESULT_OK else TestContract.RESULT_REJECTED
            setResult(code, outcome.toJson().toString(), null)
        }
    }
}
