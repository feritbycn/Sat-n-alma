package com.example.iaptest.samplegame

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.iaptest.sdk.SimEvent
import com.example.iaptest.sdk.SimWallet
import com.example.iaptest.sdk.SimType

/**
 * Örnek oyun: oyun parası, harcama ve kalıcı bakiye. Bakiye SimWallet'tadır (simülasyon).
 * Test olayları (App Test Studio'dan) yalnızca debug derlemesinde, SDK'nın debug-only
 * alıcısı üzerinden gelir; release'te bu arayüz de gösterilmez.
 */
class GameActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val wallet = SimWallet.shared(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize().safeDrawingPadding()) { GameScreen(wallet) }
            }
        }
    }
}

private const val SWORD_PRICE = 50

@Composable
private fun GameScreen(wallet: SimWallet) {
    val state by wallet.state.collectAsStateWithLifecycle()
    var shopMessage by remember { mutableStateOf<String?>(null) }
    var swords by remember { mutableStateOf(0) }

    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Örnek Oyun", style = MaterialTheme.typography.headlineSmall)
            Text("Oyun parası bakiyesi", style = MaterialTheme.typography.labelMedium)
            Text("${state.balance}", style = MaterialTheme.typography.displaySmall)
            Text("Kalıcı ürünler: " + (state.owned.takeIf { it.isNotEmpty() }?.joinToString() ?: "yok"))
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = {
                    val out = wallet.apply(SimEvent(SimType.SPEND, amount = SWORD_PRICE, txnId = "GAME-" + System.nanoTime()))
                    if (out.ok) swords++
                    shopMessage = out.message
                }) { Text("Kılıç al ($SWORD_PRICE)") }
                Text("Kılıçlarım: $swords", Modifier.padding(top = 12.dp))
            }
            shopMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }

        if (BuildConfig.DEBUG) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                    Text(
                        "TEST DERLEMESİ (debug): Bakiye SİMÜLASYONDUR. App Test Studio'dan gelen test olayları " +
                            "kabul edilir; gerçek Google Play kaydı değildir.",
                        Modifier.padding(12.dp),
                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                    )
                }
            }
            item { Text("Simülasyon işlem geçmişi", style = MaterialTheme.typography.titleSmall) }
            items(state.history.take(15), key = { it.id + it.type.name + it.time }) { t ->
                Text("${t.type.label} → ${t.status} (bakiye ${t.balanceAfter})", style = MaterialTheme.typography.bodySmall)
            }
        } else {
            item {
                Text(
                    "Gerçek satın almalar yalnızca Google Play Billing + sunucu doğrulaması ile yapılır " +
                        "(bkz. README, bölüm \"Gerçek satın alma\").",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}
