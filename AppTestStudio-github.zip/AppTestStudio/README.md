# App Test Studio

Cihazdaki uygulamaları **salt-okunur** inceleyen ve **kendi geliştirdiğiniz** oyunun satın alma akışlarını **simülasyonla** test etmenizi sağlayan, koyu temalı Kotlin / Jetpack Compose / MVVM projesi.

Bu bir yama/crack aracı değildir: başka uygulamaları değiştirmez, satın alma doğrulamasını atlatmaz, token/makbuz üretmez, root veya açık kullanmaz.

## Modüller

| Modül | Açıklama |
|---|---|
| `:app` | **App Test Studio** — yüklü uygulama listesi (arama/filtre), uygulama bilgisi sekmesi, test merkezi sekmesi |
| `:testsdk` | Ortak test SDK'sı: `SimWallet` (simüle cüzdan), olay sözleşmesi, **yalnızca debug** test alıcısı |
| `:samplegame` | Örnek oyun: oyun parası, harcama, kalıcı bakiye; SDK'yı kullanır |

## Güvenlik tasarımı

- **Salt-okunur analiz:** Yalnızca `PackageManager` ile herkese açık paket bilgisi. Başka uygulamaların verisi/dosyaları/APK'ları okunmaz ya da değiştirilmez.
- **Paket görünürlüğü:** `QUERY_ALL_PACKAGES` yok. `<queries>` ile yalnızca başlatıcıda görünen uygulamalar ve test SDK'lı uygulamalar listelenir (Android 11+ kuralları; Play politikasıyla uyumlu). Bu yüzden arka plan servisleri gibi başlatıcısız paketler listede çıkmaz.
- **Simülasyon açıkça etiketli ve ayrı:** Test merkezinde sarı "SİMÜLASYON" bandı, geçmişte "SİMÜLASYON" etiketi vardır. Veriler `SimWallet` içinde, ayrı depolama dosyalarında (`sim_wallet`, `analyzer_local_sim_wallet`) tutulur. `SimEvent`/`SimOutcome` tiplerinde token/orderId/makbuz alanı **yoktur**; işlem kimlikleri `SIM-…` önekli etikettir.
- **Test olayı yalnızca geliştirme derlemelerinde:**
  1. Alıcı ve izin yalnızca `:testsdk`'nın **debug** varyantındaki manifestte (`testsdk/src/debug`) bulunur; release APK/AAB'de yoktur.
  2. İzin `signature` düzeyindedir: yalnızca aynı anahtarla imzalı uygulama olay gönderebilir.
  3. Alıcı çalışma zamanında da uygulama `debuggable` değilse olayı reddeder.
- **Üretimde test arayüzü kapalı:** Örnek oyunda test paneli `BuildConfig.DEBUG` ile gizlenir; `TEST_BUILD` işareti yalnızca debug manifestindedir.
- **Yinelenen olay koruması:** Aynı işlem kimliği + olay türü iki kez uygulanmaz.

## Özellikler

**Uygulama listesi:** ad, simge, paket adı; arama (ad/paket) ve filtreler (Tümü, Kullanıcı, Sistem, Debuggable, Test SDK'lı); satıra dokununca ayrıntı.

**Bilgi sekmesi:** ad, paket, sürüm (ad + kod), ilk kurulum/son güncelleme, kurulum kaynağı (`getInstallSourceInfo`; Play, Galaxy Store, yan yükleme vb. — erişilemezse "bilinmiyor"), sistem/kullanıcı, cihaz SDK'sı, minSdk/targetSdk ve uyumluluk notları, `debuggable`, manifestteki **`TEST_BUILD`** işareti, test SDK alıcısı var mı, **Uygulamayı aç** düğmesi.

**Test merkezi sekmesi:** senaryolar — başarılı, iptal, başarısız, bekleyen (sonra Tamamla/İptal), geri yükleme (önce "Yerel yetkileri sil" ile veri kaybı simüle edilir, sonra "Geri yükle": kalıcı ürünler döner, **jeton bakiyesi değişmez**), sanal para bakiyesi, harcama ("50 harca"; yetersiz bakiye reddedilir), işlem geçmişi. Hedef: seçilen uygulama (SDK varsa) veya **yerel simülasyon**.

## GitHub'dan APK üretme (bilgisayarsız)

1. GitHub'da yeni bir **özel (private)** depo oluşturun ve bu klasörün içeriğini yükleyin. `.github/workflows/build-apk.yml` ve `keystore/` klasörlerinin de yüklendiğini kontrol edin (nokta ile başlayan klasör web yüklemesinde atlanırsa dosyayı elle ekleyin).
2. **Actions** sekmesi → "Build APK" → **Run workflow** (veya `main` dalına push edin).
3. İş bitince çalıştırmanın sayfasındaki **Artifacts → apks** dosyasını indirin; içinde `app-debug.apk` ve `samplegame-debug.apk` vardır. Telefona kurarken "bilinmeyen kaynaklara izin ver" gerekir.
4. Kalıcı indirme bağlantısı için `v0.1.0` gibi bir etiket (tag) oluşturun: APK'lar depo **Releases** sayfasına eklenir.

Notlar: Workflow, Gradle 8.13'ü kendisi kurar (`gradlew` dosyası pakette yok). Her iki APK de depodaki ortak **debug** anahtarıyla imzalanır (`keystore/debug.keystore`); gizli değildir ve yalnızca test içindir. Bu sayede APK'lar birbirinin üzerine kurulur ve test olayı izni çalışır. Release/Play yayını için kendi anahtarınızı kullanın. Derleme hata verirse Actions günlüğünü bana yapıştırın.

## Kurulum ve derleme

Gereksinimler: güncel Android Studio, JDK 17+, Android SDK 36.

1. Klasörü Android Studio ile açın (**Open**) ve Gradle senkronizasyonunu bekleyin. `gradle-wrapper.jar` pakette yoktur; Studio Gradle 8.13'ü indirir. Eklenti sürümleri eskirse **Upgrade Assistant** kullanın.
2. Debug APK'ları:
   ```
   ./gradlew :app:assembleDebug :samplegame:assembleDebug
   ```
   Çıktılar: `app/build/outputs/apk/debug/app-debug.apk`, `samplegame/build/outputs/apk/debug/samplegame-debug.apk`
3. Cihaza yükleme (USB hata ayıklama açık):
   ```
   ./gradlew :app:installDebug :samplegame:installDebug
   ```
4. **Aynı imza zorunludur:** İki uygulamayı **aynı makinedeki aynı debug keystore** ile derleyin (Studio varsayılanı). Farklı makinelerde derlenmiş APK'larla olay iletimi çalışmaz (izin verilmez); ortak bir keystore kullanın.
5. Release (test arayüzü ve alıcı **yoktur**): `./gradlew :samplegame:bundleRelease` / `assembleRelease` — kendi imzalama yapılandırmanızı ekleyin.

> Bu proje yazıldığı ortamda Android SDK olmadığı için derlenip çalıştırılmadı. İlk adım olarak `./gradlew test` çalıştırın; sürüm uyarısı çıkarsa Studio önerisini uygulayın.

## Test etme

Birim testleri (cihaz gerekmez): `./gradlew test`
- `SimWalletTest` (12 test): başarı/bakiye, yinelenen olay, iptal/başarısız bakiyeyi değiştirmez, bekleyen → tamamla/iptal, kalıcı ürün iki kez alınamaz, geri yükleme bakiyeyi değiştirmez, harcama ve yetersiz bakiye, **yeniden başlatmada bakiye ve geçmiş korunur**, JSON gidiş-dönüş.
- `LogicTest`: arama/filtre, kurulum kaynağı etiketleri, uyumluluk notları.

Arayüz testleri (cihaz/emülatör gerekir): `./gradlew :app:connectedDebugAndroidTest`
- `UiTest`: aramanın listeyi süzmesi; test merkezinde "SİMÜLASYON" bandı ve seçilen senaryonun gönderilmesi.

Elle uçtan uca test:
1. `samplegame`'i yükleyin ve **bir kez açın** (hiç açılmamış/durdurulmuş uygulamaya yayın ulaşmaz).
2. App Test Studio'yu açın → listede "Örnek Oyun" satırında **TEST SDK** ve **DEBUG** rozetleri görünmeli.
3. Satıra dokunun → *Bilgi*: `TEST_BUILD işareti: Evet`, `Test SDK alıcısı: Var`. **Uygulamayı aç** ile oyun açılır.
4. *Test merkezi* → hedef "Örnek Oyun" → "Başarılı" ile 100 oyun parası ürününü simüle edin. Oyunu açın: bakiye 100 görünür.
5. Oyunda **Kılıç al (50)** → bakiye 50. Oyunu kapatıp açın → bakiye korunur. Test merkezinde "Durumu sorgula" ile aynı bakiye görünür.
6. "Bekleyen" → bakiye değişmez; **Tamamla** → artar. "Yerel yetkileri sil" → "Geri yükle" ile `remove_ads` geri gelir, bakiye aynı kalır.
7. Yanıt gelmezse: iki APK'nın aynı keystore ile imzalandığını ve oyunun bir kez açıldığını kontrol edin.

## Kendi oyununuza bağlama

1. `settings.gradle.kts` içine `:testsdk` modülünü ekleyin (veya AAR olarak yayımlayın) ve oyun modülünde:
   ```kotlin
   dependencies { implementation(project(":testsdk")) }
   ```
   Alıcı/izin yalnızca debug varyantına girer; ek `debugImplementation` ayrımı gerekmez.
2. Oyun parası bakiyenizi `SimWallet` üzerinden okuyun/harcayın (`SimWallet.shared(context)`, `wallet.state`, `wallet.apply(SimEvent(SimType.SPEND, amount = 50))`) **veya** kendi bakiye sisteminiz varsa `TestEventReceiver` benzeri bir debug alıcısında `SimEvent`'leri kendi mantığınıza çevirin. `samplegame` örnek kullanımdır.
3. Debug manifestinize `com.example.iaptest.TEST_BUILD = true` meta-data'sını ekleyin (bkz. `samplegame/src/debug/AndroidManifest.xml`).
4. Ürün kimliklerini `SimCatalog` içinde kendi ürünlerinizle değiştirin.

## Gerçek satın alma (üretim)

Bu projedeki satın alma akışı **yalnızca simülasyondur** ve gerçek satın almanın yerini tutmaz. Üretimde: Google Play Billing Library + sunucu tarafı doğrulama (Google Play Developer API) + `acknowledge`/`consume`. Çalışan bir uygulaması önceki **IapTestLab** projesindedir (`GooglePlayBilling`, `RealPurchaseManager`, `PurchaseVerifier`); bu sınıfları oyununuza taşıyıp simülasyon bakiyesini gerçek bakiyeden **ayrı** tutun. Bu proje o birleşimi hazır içermez.

Referans: <https://developer.android.com/google/play/billing>
